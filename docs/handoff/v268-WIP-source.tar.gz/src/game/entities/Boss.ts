import Phaser from "phaser";
import type { WorldScene } from "../scenes/WorldScene";
import { cine3d } from "../cine3d"; // vc181 — 3D 시네마틱
import type { BossDef, BossAttackKind, BossDiffKey } from "../data";
import { elemAdvantage, elementReaction, ELEM_REACTION_META, ELEMENT_META, type ElemKey, CHAPTER_ELEM } from "../data";
import { parseStage } from "../stages";
import { registerBossAnims, loadBossFrames, bossSourceFrame, BOSS_ATLAS } from "../textures";
import { trackDamage } from "../classroom"; // v1.4.31 — 교실 공유 보스 딜 합산 (보스 대상 피해도 카운트)
import { EventBus } from "../../components/game/EventBus";
import { mitigateEnemyDamage } from "../combat/defense";
import { rng, actorStream } from "../sim/deterministic"; // vc183 — 시드 기반 결정론 난수 // vc183 — 보스 방어력
/* P7b — 페이즈 예고·반격 창 수치는 `bossPhases.ts` 가 단일 출처다(테스트가 검증).
 *  종전엔 이 값들이 Boss.ts 안에 흩어져 있어 "예고가 몇 ms 인가"를 기계적으로 확인할 수 없었다. */
import { phaseAt, telegraphMs, recoveryMs, counterWindowMs, attacksAfter, attackPool } from "./bossPhases";
/* vc288 — 정본(스토리 기획서)에 근거한 페이즈 형태 이름. 없으면 종전 문구로 폴백한다. */
import { canonBossOf, canonPhaseIndex } from "./bossDesign";
import { STORY_ATTACKS, storyPattern, type StoryAttack } from "./storyBossPatterns";
import { StoryBossMechanics } from "./StoryBossMechanics";
/**
 * 보스 (3종 — 스테이지별 정의 주입):
 *  guardian: 심연의 수호자 (알프헤임) / behemoth: 침몰의 선장 (쿠소디아 선박의 왕국) / abysslord: 심연의 군주 (심연의 왕좌)
 * F4 최적화 핵심:
 *  - 투사체는 24발 고정 풀 재사용 (런타임 생성/파괴 없음)
 *  - 텔레그래프는 미리 만든 텍스처 스프라이트 트윈 (매 프레임 Graphics 그리기 없음)
 *  - 파티클은 씬의 공유 이미터 explode() 재사용
 */

/**
 * P7b — 반격 창(recover) 동안 들어가는 피해 배율.
 *  기절(staggered, ×1.6)보다 약하다: 기절은 "카운터를 성공시킨 보상"이고,
 *  반격 창은 "아무 패턴이나 끝나면 오는 기본 리듬"이므로 보상이 더 작아야 한다.
 *  ×1 보다 크면 "패턴 사이에 때리는 게 이득"이라는 학습이 생긴다.
 */
const RECOVER_DMG_MULT = 1.15;
type BossMode =  | "idle"
  | "slamTele"
  | "chargeTele"
  | "charging"
  | "volley"
  | "ringTele"
  | "zonesTele"
  | "summonTele"
  | "dead"
  // v4.1.4 — 보스 개성 패턴
  | "beamTele" // 스윕 빔 예고
  | "beaming" // 스윕 빔 발사중
  | "blinkTele" // 그림자 급습(순간이동 준비)
  | "counterTele" // 반격 카운터 창(로스트아크식)
  | "staggered" // 카운터 성공 → 기절/취약
  | "quakeCast" // 연속 낙뢰 시전
  // vc142 (#6) — 보스 고유 VX 패턴 (유저 에셋팩 FX — 보스마다 전부 다른 공격)
  | "storyCast"
  | "vxTele" // VX 패턴 공용 예고
  | "vxCast" // VX 패턴 연출/연타 중 (피해 판정은 delayedCall 체인)
  // vc153 — 스바르트알프헤임 보스 개편 (애니 사양표 상태머신)
  | "vanished" // Vanish — 투명화 후 재배치 대기
  | "shieldHold" // ShieldCast — 방어막 상태유지 (무적 → 종료 시 마력 폭발 반격)
  | "recover" // P7b — 강력 패턴 후 무방비 구간 (반격 기회, 피해 ×1.15)
  | "spiralTele"; // P7b — 나선 탄막 전용 예고 (종전엔 volley,10 즉발)
export class Boss extends Phaser.Physics.Arcade.Sprite {
  declare scene: WorldScene;

  def: BossDef;
  hp: number;
  /** v3.0.15 (#16) — 챕터 테마 원소 */
  readonly elem: ElemKey;
  maxHp: number;
  alive = true;
  enraged = false;
  /** 현재 페이즈 (1: 100~66%, 2: 66~33%, 3: 33%~0) */
  phase = 1;
  // 근접 판정용 목표 크기 — 커다란 보스 스프라이트에 맞춰 넉넉하게
  hitW = 104;
  hitH = 108;

  private mode: BossMode = "idle";
  private visualKey = "";
  private storyReleaseAt = 0;
  private story: StoryBossMechanics | null = null;
  private modeTimer = 1200;
  private nextAttackCd = 1600;
  private knockVec = new Phaser.Math.Vector2();
  private chargeDir = new Phaser.Math.Vector2();
  private teleRing: Phaser.GameObjects.Image | null = null;
  private teleRings: Phaser.GameObjects.Image[] = [];
  /** v1.0.12 — 스콜&하티 쌍랑 표현 ("스콜밖에 안보임" 리포트): 하티(달을 쫓는 늑대)
   *  쌍둥이 유령 스프라이트 — 판정 없는 비주얼 동반자(뒤 오프셋·플립 미러·달빛 틴트). */
  private twin: Phaser.GameObjects.Sprite | null = null;
  /** 장판 패턴(존스)용 예고 링들 */
  private zoneRings: Phaser.GameObjects.Image[] = [];
  private chargeTarget = new Phaser.Math.Vector2();
  private volleyCount = 0;
  private volleyTimer: Phaser.Time.TimerEvent | null = null;
  private chargeHitDone = false;
  /** 직전 공격 종류 — 같은 패턴 연속 반복 방지 */
  private lastAttack: BossAttackKind | null = null;

  /* ---- v4.1.4 — 난이도/신규 패턴 상태 ---- */
  /** 카오스 난이도 전용 메커니즘 활성화 (재림판에서만 선택 가능) */
  chaos = false;
  /** 돌진 연쇄 잔여 횟수 (fenrir 2연속 / skoll 3연속, 카오스 +1) */
  private chargeChainLeft = 0;
  private spiralAngle = 0;
  private spiralTimer: Phaser.Time.TimerEvent | null = null;
  private beamTimer: Phaser.Time.TimerEvent | null = null;
  private beamAngle = 0;
  private beamDir = 1;
  private quakeTimer: Phaser.Time.TimerEvent | null = null;
  /** 페이즈 3 카오스 지원군 타이머 */
  private supportTimer: Phaser.Time.TimerEvent | null = null;
  /* ---- vc142 (#6) — 보스 고유 VX 패턴 상태 ---- */
  private vxKind: BossAttackKind | null = null;
  private vxStep = 0;
  /* vc153 — 스바르트알프헤임 보스 개편 상태 */
  private shieldInvuln = false; // ShieldCast 상태유지 중 피해 무효
  private shieldAura: Phaser.GameObjects.Image | null = null; // 방어막 오라 (정리 보장 대상)
  /* vc288 — 방어막 남은 시간 게이지. 시간제 무적의 종료 시점을 보여 준다. */
  private shieldGauge: Phaser.GameObjects.Graphics | null = null;
  private shieldGaugeTimer: Phaser.Time.TimerEvent | null = null;
  /* vc288 (REVAMP_ABC_300 B39) — 격노 오라. HP 30% 이하(페이즈 3)에서 보스 발밑에
   *  붉은 고리가 깜박인다. 종전엔 `enraged` 가 이동속도·공격력에만 영향을 줘서
   *  **화면상으로는 격노한 것을 알 수 없었다** — 유저는 갑자기 빨라진 보스를 보며
   *  "왜 갑자기 세지?" 만 느꼈다. */
  private enrageAura: Phaser.GameObjects.Graphics | null = null;
  private enrageAuraTimer: Phaser.Time.TimerEvent | null = null;
  /** 독 장판 (nidhog/jorm poisonfield) — 밟으면 도트 피해 */
  private poisonZones: { x: number; y: number; until: number; img: Phaser.GameObjects.Image; last: number }[] = [];
  /** 카운터 창 텔레그래프 링 */
  private counterRing: Phaser.GameObjects.Image | null = null;
  /* v1.4.30 (#15) — 반격 창 라벨 (startCounter에서 생성, destroyCounterRing에서 소멸) */
  private counterLabel: Phaser.GameObjects.Text | null = null;
  private counterHintShown = 0;
  private recoveryLabel: Phaser.GameObjects.Text | null = null;

  /* ---- v1.4.9 — 보스 생동감 애니메이션 (호흡·예동·낙하 등장) ---- */
  private baseSX = 1;
  private baseSY = 1;
  /* vc183 — 시작 타이머도 시드에서 뽑는다. Math.random 이면 같은 판을 재현할 수 없다. */
  private breathT = rng().float(0, 4000);
  private squashX = 0;
  private squashY = 0;
  private entranceDone = false;
  /* vc288 — 보스 등장 직후 전투 개시까지의 카운트다운(초). 0 이면 끝난 상태.
   *  유저 요구 "보스 시작 전 카운트다운"이 미구현이었다. 낙하 착지와 동시에 공격이
   *  시작되면, 화면을 보고 준비할 틈이 없어 "맞으면서 시작"이 된다.
   *  이 값이 0 보다 큰 동안은 보스가 아무 행동도 하지 않는다(update 조기 반환). */
  private countdown = 0;
  private countdownTimer: Phaser.Time.TimerEvent | null = null;

  // F4: 투사체 고정 풀
  private orbPool: Phaser.Physics.Arcade.Image[] = [];
  private orbIdx = 0;

  /** v1.4.31 (#4) — 트윈(하티)이 본체와 다른 텍스처를 쓸 때의 애니 프리픽스 (boss_skoll → boss_hati) */
  private twinPrefix: string | null = null;

  constructor(scene: WorldScene, x: number, y: number, def: BossDef, diffKey: BossDiffKey = "normal") {
    /* v1.4.31 (#4 보스 개편) — 아틀라스 보스는 시트 frame 0, 구형은 개별 idle0 이미지 */
    const src = bossSourceFrame(def.tex);
    super(scene, x, y, src.key, src.frame);
    this.def = def;
    /* vc183 (지시 — 적에게도 방어력) — 보스 기본 방어력.
     *  보스는 잡몹보다 단단해야 "체력이 많은 벽"이 아니라 "때려도 덜 박히는 벽"이 된다.
     *  정액 25 + 비율 10%를 기본으로 주고, BossDef 에 값이 있으면 그쪽이 우선한다.
     *  카오스는 한 단계 더 단단(비율 14%) — 난이도 선택이 실감나게. */
    if (def.def === undefined) def.def = 25;
    if (def.defPct === undefined) def.defPct = diffKey === "chaos" ? 0.14 : 0.10;
    this.chaos = diffKey === "chaos"; // v4.1.4 — 카오스 전용 메커니즘 플래그
    this.elem = CHAPTER_ELEM[parseStage(scene.stageDef.key).ch] ?? "dark"; // v3.0.15 (#16) 챕터 테마 원소
    this.hp = def.hp;
    this.maxHp = def.hp;
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.setDepth(11);
    /* vc181 (지시 #7 — "보스 크기 적용 안됨"):
     *  종전엔 보스 스케일을 아무도 지정하지 않아 `scaleX || 1` = 항상 1배였다.
     *  그런데 BOSS_ATLAS 프레임 크기가 보스마다 156×163 ~ 330×212 로 제각각이라
     *  (nidhog는 작게, boss2는 크게) 화면에서 차지하는 크기가 들쭉날쭉했다.
     *  → 목표 표시 높이(320px)로 정규화해 모든 보스가 같은 체급으로 보이게 한다.
     *    (소스 프레임이 작은 보스는 확대, 큰 보스는 축소 — 판정도 displayWidth 기준이라 함께 맞는다) */
    {
      const TARGET_H = 320;
      const srcH = this.height || 1;
      const s = Phaser.Math.Clamp(TARGET_H / srcH, 0.55, 2.6);
      this.setScale(s);
    }
    // 보스 스프라이트 크기에 비례한 히트박스/근접 판정
    /* vc181 — 스케일 정규화 후에는 displayWidth/displayHeight(스케일 반영값)를 써야
     *  판정이 그림과 일치한다. 종전엔 원본 width/height만 써서, 축소된 보스는
     *  그림보다 판정이 크고 확대된 보스는 작았다. */
    const bw = Math.round(this.displayWidth * 0.66);
    const bh = Math.round(this.displayHeight * 0.6);
    this.body!.setSize(bw, bh);
    this.body!.setOffset((this.width - bw) / 2, this.height - bh - 6);
    /* v1.4.31 (#4) — 아틀라스 프레임은 300px급 대형화 — 근접 판정도 표시 크기(displayWidth) 기준 */
    this.hitW = Math.round(this.displayWidth * 0.92);
    this.hitH = Math.round(this.displayHeight * 0.92);
    // 돌진/넉백으로 아레나 밖으로 나가지 않도록 경계 충돌
    (this.body as Phaser.Physics.Arcade.Body).setCollideWorldBounds(true);
    /* v5.0 보스 전면 리메이크 — 12FPS 풀애니(idle/walk/atk/die/sp1~3):
     *  캐시된 프레임 즉시 애니 등록 + 나머지 프레임 지연 로드 후 애니 승격(무결성 폴백)
     *  v1.4.31 (#4) — 애니 등록을 play보다 먼저 (아틀라스 보스는 부팅 폴백 애니가 없다) */
    if (!def.tex.startsWith("cast_") && !def.tex.startsWith("story_")) {
      registerBossAnims(scene, def.tex);
      if (!BOSS_ATLAS[def.tex]) void loadBossFrames(scene, def.tex);
      this.play(`${def.tex}-idle`);
    }

    this.visualKey = def.tex;
    if (def.tex.startsWith("cast_") || def.tex.startsWith("story_")) this.applyStoryVisual(def.tex);
    this.story = new StoryBossMechanics(this);

    /* v1.0.12 — 하티 스폰: 스콜 옆에 나란히 달린다.
     *  vc142 — 아틀라스 시대: 본체=얼음 늑대(스콜), 트윈=화염 늑대(하티 전용 아트·무틴트).
     *  구형 아트는 기존대로 동일 텍스처+은빛 틴트. 히트박스/판정은 보스 본체 그대로(밸런스 불변). */
    if (def.key === "skoll" && !canonBossOf(def.key)) {
      if (BOSS_ATLAS[def.tex]) {
        this.twinPrefix = "boss_hati";
        this.twin = scene.add.sprite(this.x, this.y, "atl_boss_hati", 0)
          .setDepth(this.depth - 1)
          .setAlpha(0); // v1.4.9 — 낙하 등장 중 비표시, 착지 시 0.95로 복원
        this.twin.play("boss_hati-idle");
      } else {
        this.twin = scene.add.sprite(this.x, this.y, this.texture.key)
          .setDepth(this.depth - 1)
          .setTint(0x9fb8ff)
          .setAlpha(0);
        this.twin.play(`${def.tex}-idle`);
      }
      this.twin.setFlipX(true);
    }

    for (let i = 0; i < 44; i++) {
      const orb = scene.physics.add.image(0, 0, "orb");
      // 외부 에셋 구슬(Kenney circle_05) — 보스별 테마색 발광 에너지탄
      orb.setTint(def.orbTint).setBlendMode(Phaser.BlendModes.ADD);
      orb.setActive(false).setVisible(false);
      orb.setData("dmg", def.atk);
      (orb.body as Phaser.Physics.Arcade.Body).setCircle(7);
      this.orbPool.push(orb);
    }

    // v4.1.4 — 카오스 등장 연출은 착지 후 개시로 이동 (등장 페이드와 충돌 방지 — startChaosAura)
    /* v1.4.9 — 등장 연출: 하늘 높이에서 낙하 착지 (충격파+먼지+진동+착지 찌그러짐).
     *  착지 전까지 물리 바디 비활성 + 행동 정지(entranceDone) — 낙하 중 공격/충돌 없음 */
    this.baseSX = this.scaleX || 1;
    this.baseSY = this.scaleY || 1;
    const landY = this.y;
    const body = this.body as Phaser.Physics.Arcade.Body;
    body.enable = false;
    this.setAlpha(0);
    this.setY(landY - 150);
    this.scene.tweens.add({ targets: this, alpha: 1, duration: 170 });
    this.scene.tweens.add({
      targets: this,
      y: landY,
      duration: 540,
      ease: "Bounce.easeOut",
      onComplete: () => {
        this.entranceDone = true;
        body.reset(this.x, landY);
        body.enable = true;
        this.squash(0.16, -0.16); // 착지 충격
        this.twin?.setAlpha(0.95);
        this.scene.spawnShockwave(this.x, this.y + 10, this.def.orbTint, 1.15, 420);
        this.scene.spawnBurstAt(this.x, this.y + 12, 12, 0xffffff);
        this.scene.impactFX.shake(150, 0.007);
        this.startChaosAura();
        this.startCountdown();
      },
    });
  }

  /** v1.4.9 — 카오스 붉은 오라 펄스 (착지 후 개시) */
  private startChaosAura() {
    if (!this.chaos || !this.alive) return;
    this.scene.tweens.add({
      targets: this,
      alpha: { from: 1, to: 0.86 },
      duration: 420,
      yoyo: true,
      repeat: -1,
    });
  }

  /**
   * vc288 (REVAMP_ABC_300 B39) — 격노 오라. 페이즈 3 진입(=HP 33% 이하) 시 보스 발밑에
   * 붉은 고리가 맥동한다.
   *
   * [왜 필요한가]
   *  `enraged` 플래그는 이미 있었지만 이동속도 1.18배·공격력 0.75배에만 영향을 줬다.
   *  **화면에는 아무 표시가 없었다.** 유저는 갑자기 빨라진 보스를 보며 이유를 알 수
   *  없었고, "내가 뭘 잘못했나" 로 오해하기 쉬웠다. 위기 상태는 눈에 보여야 한다.
   *
   * [동작]
   *  2중 고리를 90ms 간격으로 다시 그린다(반경과 투명도가 미세하게 맥동).
   *  Graphics 를 매 프레임 새로 만들지 않고 **하나를 clear() 후 재사용**한다 —
   *  이 프로젝트에서 자주 호출되는 지점은 할당을 피하는 규칙(ponytail)을 따른다.
   *  보스가 죽거나 씬이 바뀌면 destroyPool() 이 정리한다.
   */
  private startEnrageAura() {
    if (!this.alive || this.enrageAura) return;
    const g = this.scene.add.graphics();
    g.setDepth(this.depth - 1); // 보스 뒤에 깔아 스프라이트를 가리지 않는다
    this.enrageAura = g;

    let t = 0;
    this.enrageAuraTimer = this.scene.time.addEvent({
      delay: 90,
      loop: true,
      callback: () => {
        if (!this.alive || !this.enrageAura) return;
        t += 0.15;
        /* 0~1 맥동 — sin 으로 부드럽게. 반경 34~42, 투명도 0.20~0.42 */
        const k = (Math.sin(t) + 1) / 2;
        const r = 34 + k * 8;
        g.clear();
        g.setPosition(this.x, this.y + 12);
        /* 바깥 고리 — 옅고 넓다 */
        g.lineStyle(3, 0xff4a6a, 0.14 + k * 0.16);
        g.strokeCircle(0, 0, r + 4);
        /* 안쪽 고리 — 진하고 좁다 */
        g.lineStyle(2, 0xff8090, 0.22 + k * 0.20);
        g.strokeCircle(0, 0, r);
      },
    });
  }

  /**
   * vc288 — 보스전 개시 카운트다운 (3 → 2 → 1 → 시작).
   *
   * [왜 필요한가]
   *  종전엔 낙하 착지와 **동시에** 공격이 시작됐다. 유저는 보스가 어디에 섰는지,
   *  내가 어디 있는지를 볼 틈도 없이 첫 패턴을 맞았다. 보스전의 첫 3초가
   *  "읽을 시간"이 아니라 "얻어맞는 시간"이었던 셈이다.
   *
   * [동작]
   *  착지 직후 1초 간격으로 3·2·1 을 배너에 띄우고, 그동안 `tick()` 은 조기 반환한다.
   *  카운트가 끝나면 "시작!" 을 띄우고 정상 전투로 넘어간다.
   *  씬이 사라지면 타이머도 같이 정리된다(TimerEvent 는 씬 소속이므로 자동 소멸하지만,
   *  보스가 죽어 destroy 되는 경우를 대비해 onDie/cleanup 에서 remove 한다).
   *
   * ponytail: 카운트 길이를 바꾸려면 COUNTDOWN_STEPS 만 고친다.
   *  값을 늘리면 "준비 시간"이 늘어나지만 템포가 죽는다 — 3초가 현재 균형점이다.
   */
  private startCountdown() {
    const STEPS = 3;
    this.countdown = STEPS;
    this.scene.showBanner(`${this.def.name} — ${STEPS}`);
    this.scene.sfxRoar();
    this.countdownTimer?.remove();
    this.countdownTimer = this.scene.time.addEvent({
      delay: 1000,
      repeat: STEPS - 1,
      callback: () => {
        if (!this.alive) {
          this.countdown = 0;
          return;
        }
        this.countdown = Math.max(0, this.countdown - 1);
        if (this.countdown > 0) {
          this.scene.showBanner(`${this.def.name} — ${this.countdown}`);
        } else {
          this.scene.showBanner("시작!");
          this.scene.impactFX.shake(120, 0.006);
        }
      },
    });
  }

  private applyStoryVisual(texture: string) {
    const combat = texture.startsWith("cast_") ? texture.replace("cast_", "story_") : texture;
    const key = this.scene.textures.exists(combat) ? combat : texture;
    this.visualKey = key;
    this.setTexture(key, key.startsWith("story_") ? "idle-0" : "idle-down-0").setOrigin(.5, .65);
    const large = ["story_kraken", "story_starplanet", "story_aicore"].includes(key);
    this.setScale(large ? .9 : key.startsWith("story_") ? .58 : 1.05);
    const bw = key.startsWith("story_") ? (large ? 175 : 86) : 38;
    const bh = key.startsWith("story_") ? (large ? 110 : 114) : 60;
    this.body!.setSize(bw, bh); this.body!.setOffset((this.width - bw) / 2, this.height - bh - (key.startsWith("story_") ? 18 : 6));
    this.hitW = large ? 155 : 58; this.hitH = large ? 120 : 82;
    this.baseSX = this.scaleX; this.baseSY = this.scaleY;
    const idle = `${key}-idle`; if (this.scene.anims.exists(idle)) this.play(idle);
  }

  /** v1.4.9 — 예동(스쿼시&스트레치): 양수=누르기, 음수=쭉 펴기. preUpdate에서 지수 감쇠로 자연 복원 */
  private squash(x: number, y: number) {
    this.squashX = x;
    this.squashY = y;
  }

  /* ═══ v5.0 보스 전면 리메이크 — 모드별 풀애니 (12FPS 시트) ═══
   *  idle=대기/호흡 · walk=이동/돌진 · atk=근접 강타 · sp1=지면기 · sp2=탄막/소환 · sp3=브레스/빔 · die=사망
   *  프레임 미로드/미보유 애니는 자동 폴백(기존 idle 동작 유지) */
  private animFor(): string {
    const t = this.visualKey || this.def.tex;
    switch (this.mode) {
      case "dead":
        return `${t}-die`;
      case "slamTele":
      case "counterTele":
        return `${t}-atk`;
      case "chargeTele":
      case "charging":
      case "blinkTele":
        return `${t}-walk`;
      case "volley":
      case "ringTele":
      case "summonTele":
      case "spiralTele": // P7b — 나선 예고는 탄막 계열 자세(sp2)
        return `${t}-sp2`;
      case "vxTele":
      case "vxCast":
        return `${t}-${this.vxKind === "blinkslash" ? "atk" : "sp3"}`;
      case "shieldHold":
        return `${t}-sp1`;
      case "vanished":
        return `${t}-walk`;
      case "storyCast":
        return `${t}-${this.scene.time.now < this.storyReleaseAt ? "windup" : "release"}`;
      case "zonesTele":
      case "quakeCast":
        return `${t}-sp1`;
      case "beamTele":
      case "beaming":
        return `${t}-sp3`;
      case "staggered":
        return `${t}-idle`;
      case "recover":
        return `${t}-idle`; // P7b — 무방비 창은 숨 고르는 자세
      case "idle": {
        const v = this.body?.velocity;
        return v && Math.abs(v.x) + Math.abs(v.y) > 24 ? `${t}-walk` : `${t}-idle`;
      }
    }
    return `${t}-idle`;
  }

  /** 애니 전환 (미보유 애니 → idle 폴백). 현재 애니와 같으면 무시 — 루프 유지 */
  private setBossAnim(key: string) {
    const a = this.scene.anims;
    const want = a.exists(key) ? key : `${this.visualKey || this.def.tex}-idle`;
    if (!a.exists(want) || this.anims.currentAnim?.key === want) return;
    this.play(want);
    if (want.endsWith("-windup")) {
      const duration = Math.max(100, this.storyReleaseAt - this.scene.time.now);
      this.anims.timeScale = this.anims.currentAnim!.duration / duration;
    } else this.anims.timeScale = 1;
    /* v1.4.31 (#4) — 트윈이 다른 텍스처(하티)면 대응 애니키로 치환해 동기화 */
    if (this.twin) {
      const twinWant = this.twinPrefix && want.startsWith(`${this.def.tex}-`)
        ? `${this.twinPrefix}-${want.slice(this.def.tex.length + 1)}`
        : want;
      if (a.exists(twinWant)) this.twin.play(twinWant);
    }
  }

  /** v1.0.12 — 하티 동기화: 프레임마다 보스 뒤 오프셋에 붙어 같이 달린다 (tick 흐름과 무관)
   *  v1.4.9 — + 생동감 애니메이션: 호흡(±2.2% 부피 보존 펄스) + 예동 감쇠 적용 */
  preUpdate(time: number, delta: number) {
    super.preUpdate(time, delta);
    this.updateRecoveryCue();
    /* vc183 — 지속 피해 틱 */
    if (this.alive) this.tickDot(time);
    if (this.twin?.active) {
      /* v1.4.31 (#4) — 오프셋을 표시 폭 비례로 (아틀라스 300px급 프레임 대응) */
      const off = Math.round(this.displayWidth * 0.22);
      this.twin.setPosition(this.x + (this.flipX ? -off : off), this.y + 2);
      this.twin.setFlipX(!this.flipX);
      this.twin.setDepth(this.depth - 1);
    }
    if (!this.alive) return;
    this.breathT += delta;
    const decay = Math.pow(0.5, delta / 200);
    this.squashX *= decay;
    this.squashY *= decay;
    const breathe = Math.sin(this.breathT / 300) * 0.022; // ±2.2% 호흡
    this.scaleX = this.baseSX * (1 - breathe * 0.6 + this.squashX);
    this.scaleY = this.baseSY * (1 + breathe + this.squashY);
    this.twin?.setScale(this.scaleX, this.scaleY);
  }

  /** Reuse the existing recovery window, distinct from the yellow counter challenge. */
  private updateRecoveryCue() {
    const open = this.alive && this.mode === "recover" && this.modeTimer > 0;
    if (!open) { this.recoveryLabel?.setVisible(false); return; }
    if (!this.recoveryLabel) {
      this.recoveryLabel = this.scene.add.text(0, 0, "", {
        fontFamily: "Galmuri11, sans-serif", fontSize: "13px", color: "#decaff",
        stroke: "#1a1020", strokeThickness: 5, fontStyle: "bold",
      }).setOrigin(0.5);
    }
    this.recoveryLabel.setVisible(true).setPosition(this.x, this.y - 74).setDepth(this.depth + 1)
      .setText(`공격 기회 · 피해 +15% · ${(Math.ceil(this.modeTimer / 100) / 10).toFixed(1)}초`);
  }

  tick(dt: number, player: PlayerLike2) {
    if (!this.alive || !this.entranceDone) return; // v1.4.9 — 낙하 등장 중 행동 정지
    /* vc288 — 카운트다운 중에는 아무 것도 하지 않는다. 사용자가 화면을 읽고
     *  위치를 잡을 시간을 준다. 타이머가 0 으로 만든 뒤부터 정상 동작. */
    if (this.countdown > 0) return;
    this.modeTimer -= dt;
    this.knockVec.scale(Math.pow(0.002, dt / 1000));

    // v2.0 프롤로그 보호 — 인트로/입장 유예 중 보스 행동 정지 (투사체는 유지)
    if (this.scene.isPrologueSafe) {
      this.setVelocity(0, 0);
      this.setBossAnim(`${this.visualKey || this.def.tex}-idle`);
      return;
    }
    // v5.0 — 모드/이동 기반 애니 갱신 (매 틱 평가, 전환 시에만 play)
    this.setBossAnim(this.animFor());

    const toPlayer = new Phaser.Math.Vector2(player.x - this.x, player.y - this.y).normalize();
    const dist = Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y);

    this.updatePhase();
    if (this.story?.tick()) {
      this.scene.showBanner("링 아웃 — 파비앙의 항복!");
      this.hp = 1; this.takeDamage(this.maxHp * 100, new Phaser.Math.Vector2(), 0);
      return;
    }

    // 투사체-플레이어 충돌 (풀 순회, 44개 고정 — 저렴함)
    // v3.0.6 — 보스 공격은 방어력 50% 관통 (pierce 0.5)
    for (const orb of this.orbPool) {
      if (!orb.active) continue;
      if (Phaser.Math.Distance.Between(orb.x, orb.y, player.x, player.y) < 26) {
        player.takeDamage(
          orb.getData("dmg"),
          new Phaser.Math.Vector2(orb.body!.velocity.x, orb.body!.velocity.y).normalize(),
          0.5,
          /* v1.4.41 (#8) — 고정 % 피해는 카오스 보스에만. 일반 보스 탄막은 수치 피해만. */
          this.chaos ? 0.09 : 0
        );
        this.killOrb(orb);
      }
      if (orb.active && (orb.x < 0 || orb.x > this.scene.stageW || orb.y < 0 || orb.y > this.scene.stageH)) {
        this.killOrb(orb);
      }
    }
    // v3.0.6 — 격노 시 추격 속도 상승
    const chaseMul = this.enraged ? 1.18 : 1;

    /* vc142 (#6) — 독 장판 도트 판정 (poisonfield 지속 중) */
    this.tickPoisonZones(player);

    switch (this.mode) {
      case "idle": {
        // 추격하며 접근 — v3.0.6: 페이즈별 속도 (격노 1.18배)
        this.setVelocity(toPlayer.x * this.def.speed * chaseMul + this.knockVec.x, toPlayer.y * this.def.speed * chaseMul + this.knockVec.y);
        this.nextAttackCd -= dt;
        if (this.nextAttackCd <= 0 && dist < 560 && player.hp > 0) {
          this.pickAttack(player, dist);
        }
        break;
      }
      case "storyCast": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        if (this.modeTimer <= 0) this.endAttack(1500);
        break;
      }
      case "slamTele": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        if (this.modeTimer <= 0) this.doSlam(player);
        break;
      }
      case "chargeTele": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        this.setTint(0xff9060);
        if (this.modeTimer <= 0) {
          this.clearTint();
          this.squash(0.12, -0.08); // v1.4.9 — 돌진 출발 러닝 스트레치
          this.chargeDir.set(player.x - this.x, player.y - this.y).normalize();
          this.chargeTarget.set(player.x, player.y);
          this.setMode("charging", 520);
          this.chargeHitDone = false;
          this.scene.sfxDash();
        }
        break;
      }
      case "charging": {
        this.setVelocity(this.chargeDir.x * 520 + this.knockVec.x, this.chargeDir.y * 520 + this.knockVec.y);
        if (!this.chargeHitDone && dist < 64) {
          this.chargeHitDone = true;
          player.takeDamage(Math.round(this.def.atk * 1.1), this.chargeDir.clone(), 0.5, this.chaos ? 0.10 : 0); // v3.0.6 — 관통 + maxHP % 하한
        }
        if (this.modeTimer <= 0) {
          // v4.1.4 — 돌진 연쇄 (fenrir/skoll 고유성, 카오스 +1): 끝나면 짧은 예고 뒤 재돌진
          if (this.chargeChainLeft > 0 && player.hp > 0) {
            this.chargeChainLeft--;
            this.setMode("chargeTele", this.chaos ? 240 : 320);
          } else {
            this.endAttack(1400);
          }
        }
        break;
      }
      case "ringTele": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        if (this.modeTimer <= 0) this.doRing();
        break;
      }
      case "zonesTele": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        if (this.modeTimer <= 0) this.doZones(player);
        break;
      }
      case "summonTele": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        if (this.modeTimer <= 0) this.doSummon();
        break;
      }
      /* ---- v4.1.4 — 신규 개성 패턴 상태 ---- */
      case "beamTele": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        if (this.modeTimer <= 0) this.doBeam();
        break;
      }
      case "beaming": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        break;
      }
      case "blinkTele": {
        this.setVelocity(0, 0);
        if (this.modeTimer <= 0) this.doBlink(player);
        break;
      }
      /* ---- vc153 — 스바르트알프헤임 보스 개편 (애니 사양표 상태머신) ---- */
      case "vanished": {
        /* Vanish(Once) → 투명 유지 — 타이머 만료 시 다른 위치에서 재등장 (PortalTeleport 연출 공유) */
        this.setVelocity(0, 0);
        if (this.modeTimer <= 0) this.doReappear(player);
        break;
      }
      case "shieldHold": {
        /* ShieldCast(Once→상태유지) — 무적 방어막 유지, 타이머 만료 시 마력 폭발 반격 */
        this.setVelocity(0, 0);
        this.shieldAura?.setPosition(this.x, this.y - 6); // 오라 추적
        if (this.modeTimer <= 0) this.doShieldBurst(player);
        break;
      }
      case "counterTele": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        if (this.modeTimer <= 0) this.doCounterPunish(player);
        break;
      }
      /* ---- vc142 (#6) — 보스 고유 VX 패턴 ---- */
      case "vxTele": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        if (this.modeTimer <= 0) this.doVx(player);
        break;
      }
      case "vxCast": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        break;
      }
      case "staggered": {
        this.setVelocity(0, 0);
        if (this.modeTimer <= 0) {
          this.clearTint();
          this.endAttack(700);
        }
        break;
      }
      /* P7b — 반격 기회 창. 강력 패턴이 끝난 직후 보스가 짧게 무방비가 된다.
       *  이 동안 피해가 ×1.15 로 들어가고, 다음 공격까지 쿨이 그대로 흐른다.
       *  vc264 처럼 "패턴만 계속하고 때릴 틈이 없는" 보스전을 막는 장치다. */
      case "recover": {
        this.setVelocity(0, 0);
        if (this.modeTimer <= 0) {
          this.clearTint();
          this.mode = "idle";
        }
        break;
      }
      case "quakeCast": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        if (this.modeTimer <= 0) this.mode = "idle"; // 낙뢰 자체는 delayedCall로 계속
        break;
      }
      case "volley": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        break;
      }
      /* P7b — 나선 탄막 예고 (예고 자세 유지 → delayedCall 이 fireSpiral 호출) */
      case "spiralTele": {
        this.setVelocity(this.knockVec.x, this.knockVec.y);
        break;
      }
      default:
        break;
    }

    /* v1.4.12 (#18 보스가 플레이어 반대 방향을 바라보는 버그) — 근원 2가지:
     *  ①기존엔 이동 속도 부호만 봤다 → 정지 상태(속도 0)에선 마지막 방향을 유지해
     *    플레이어가 뒤로 돌면 뒷돌기 ②교체된 아트가 오른쪽 기준일 땐 부호가 반대로 해석됨.
     *  이제 항상 플레이어 위치 기준으로 정면을 향하고, 아트 기준 방향(faceLeft)을 존중한다. */
    const playerOnLeft = player.x < this.x;
    this.setFlipX(this.def.faceLeft ? !playerOnLeft : playerOnLeft);
  }

  /* ---------- 페이즈 관리 ---------- */

  /** HP 비율 기준 페이즈 계산 — 전환 시 연출 + 패턴 풀 확장
   *  P7b — 66%/33% → 60%/30%. 임계값은 `bossPhases.ts` 단일 출처.
   *  종전 66/33 은 10%p 눈금과 어긋나 "지금 바뀌었나"를 체감하기 어려웠다. */
  private updatePhase() {
    const canon = canonPhaseIndex(this.def.key, this.hp / this.maxHp);
    const next = canon >= 0 ? canon + 1 : phaseAt(this.hp / this.maxHp);
    if (next > this.phase) {
      this.phase = next;
      this.onPhaseChange();
    }
  }

  private onPhaseChange() {
    if (!this.alive) return;
    this.story?.phaseChanged();
    const visual = canonBossOf(this.def.key)?.phases[this.phase - 1]?.visual;
    if (visual) this.applyStoryVisual(visual);
    /* vc181 (지시 #1·#2) — 페이즈 전환은 보스전의 최대 고비다. 3D 파편/링이
     *  사방으로 터지며 카메라가 풀백하는 연출을 얹어 "지금 뭔가 변했다"를 각인시킨다. */
    void cine3d().play({ preset: "bossPattern", x: this.x, y: this.y, tint: this.phase === 3 ? 0xff4a3a : 0xffa24a, duration: 1300 });
    try { this.scene.pxFx?.boss("boss.intro", this.x, this.y, { scale: 1.4 }); } catch { /* 무시 */ }
    this.volleyTimer?.remove();
    this.clearTint();
    /* vc153 — 스바르트알프헤임 방어막/투명화 잔존 정리 (페이즈 전환 시에도 상태 유출 금지) */
    this.cleanupSvartStates();
    if (this.mode === "vanished" || this.mode === "shieldHold") this.endAttack(900);
    this.mode = "idle";
    this.nextAttackCd = 900;
    if (this.phase === 3) {
      this.enraged = true;
      /* vc288 (B39) — 격노를 화면에 보여 준다 */
      this.startEnrageAura();
      // v4.1.4 — 카오스 페이즈 3: 권속 지원군 (summonKey가 있는 보스 한정, 12초마다 1마리)
      if (this.chaos && this.def.summonKey && !this.supportTimer) {
        this.supportTimer = this.scene.time.addEvent({
          delay: 12000,
          loop: true,
          callback: () => {
            if (!this.alive || this.scene.enemies.length >= 9) return;
            this.scene.requestSummon(this.def.summonKey!, 1, this.x, this.y);
            this.scene.spawnBurstAt(this.x, this.y, 10, 0xff6a7d);
          },
        });
      }
    }
    this.scene.sfxRoar();
    this.scene.impactFX.shake(220, this.phase === 3 ? 0.01 : 0.007);
    /* v4.9.3 — 페이즈 전환 픽셀 연출. 3페이즈(격노)는 더 크게 터뜨린다. */
    try {
      this.scene.pxFx?.impact(this.phase === 3 ? "boss.enrage" : "boss.phase", this.x, this.y, 0.012, { scale: 1.6 });
    } catch { /* 연출 실패는 전투를 막지 않는다 */ }
    this.scene.spawnBurstAt(this.x, this.y, 20, this.def.orbTint);
    /* v1.1.3 (#개편 연출) — 페이즈 전환 0.18초 슬로우모션.
     *  종전엔 흔들림+플래시만 있어 전투가 계속 굴러가는 느낌이었다. 짧게 시간을 늦추면
     *  "지금 뭔가 바뀌었다"가 몸으로 전달된다. timeScale은 원상복구를 반드시 예약한다
     *  (보스가 이 사이 죽어도 복구 타이머는 씬이 살아 있는 한 실행된다).
     *  fxLevel 0(저사양 절전)에서는 생략 — 느린 화면이 오히려 렉으로 보이기 때문. */
    if (this.scene.fxLevel === 1) {
      const prevScale = this.scene.time.timeScale;
      this.scene.time.timeScale = 0.35;
      this.scene.tweens.timeScale = 0.35;
      this.scene.time.delayedCall(180 * 0.35 + 20, () => {
        this.scene.time.timeScale = prevScale;
        this.scene.tweens.timeScale = 1;
      });
    }
    /* v1.4.11 — 페이즈 전환 대형 플래시 + 룬진 펄스 (hv2_flash2·hv2_magiccircle2) */
    this.bossFx("hv2_flash2", this.x, this.y - 20, { tint: 0xffffff, scale: 2.1, alpha: 0.7, dur: 320, depth: 29 });
    this.bossFx("hv2_magiccircle2", this.x, this.y + 8, { tint: this.def.orbTint, scale: 1.5, alpha: 0.8, dur: 620, depth: 8 });
    this.squash(-0.1, 0.16); // v1.4.9 — 페이즈 포효 자세
    /* [vc288 — 정본 페이즈] 유저 요구: "모든 주요 보스는 단순 체력 많은 몬스터가 되어서는 안 된다."
     *  종전 배너는 "2 페이즈!" / "최후의 힘을 해방한다!" 뿐이라, 유저는 **무엇으로 변했는지**
     *  알 수 없었다. 정본(bossDesign.ts)에 형태 이름이 있으면 그걸 쓴다 —
     *  해롤드는 "크라켄", 페르온은 "검은 드래곤", 스칼렛은 "아이온 · 알다바오트".
     *  `this.phase` 는 1부터 시작하므로 배열 인덱스는 -1. 정본이 없는 보스는 종전 문구 그대로. */
    const canonForm = canonBossOf(this.def.key)?.phases[this.phase - 1]?.form;
    this.scene.showBanner(
      canonForm
        ? `${this.def.name} — ${canonForm}`
        : this.phase === 3
          ? `${this.def.name} — 최후의 힘을 해방한다!`
          : `${this.def.name} — 2 페이즈!`,
    );
    // 페이즈 전환 플래시
    this.setTint(0xffffff).setTintMode(Phaser.TintModes.FILL);
    this.scene.time.delayedCall(120, () => this.alive && this.clearTint());
  }

  /** 페이즈 패턴 풀에서 공격 선택 (직전 공격 제외 — 연속 반복 방지) */
  private pickAttack(player: PlayerLike2, dist: number) {
    /* P7b — 후보 풀은 `bossPhases.attackPool` 이 만든다(페이즈 누적 확장).
     *  종전엔 p3 에서 p1 패턴이 통째로 사라지는 보스가 2종 있었다
     *  (abysslord: 자기 시그니처 greenslash·slam 이 p3 에 없음 / skoll: slam).
     *  그래서 abysslord 는 sig 가중치(2.6배)를 줘도 후보에 없어 **영원히 안 나왔다**. */
    let candidates = attackPool(this.def.patterns, this.phase) as BossAttackKind[];
    candidates = candidates.filter((k) => k !== this.lastAttack);
    if (candidates.length === 0) candidates = attackPool(this.def.patterns, this.phase) as BossAttackKind[];
    /* v1.4.12 (#20 보스마다 패턴 차별화) — 시그니처 패턴 가중치 뽑기:
     *  보스별 정체성 패턴(sig)이 2.6배 확률로 나온다 — 수호자는 강타, 펜리르는 돌진,
     *  가름은 반격처럼 각자의 전투 스타일이 체감된다. */
    const sig = this.def.sig;
    let kind: BossAttackKind;
    if (sig && candidates.includes(sig)) {
      const weight = (k: BossAttackKind) => (k === sig ? 2.6 : 1);
      const total = candidates.reduce((s2, k) => s2 + weight(k), 0);
      /* vc183 — 보스 패턴 선택을 시드 기반으로. 같은 시드·같은 상황이면 같은 패턴이 나온다
       *  (버그 재현·리플레이의 전제). */
      let roll = rng().next() * total;
      kind = candidates[candidates.length - 1];
      for (const k of candidates) {
        roll -= weight(k);
        if (roll <= 0) { kind = k; break; }
      }
    } else {
      kind = Phaser.Utils.Array.GetRandom(candidates);
    }
    this.lastAttack = kind;
    if ((STORY_ATTACKS as readonly string[]).includes(kind)) {
      const k = kind as StoryAttack;
      const duration = storyPattern(k, { x: this.x, y: this.y, phase: this.phase, key: this.def.key }, player).duration;
      this.storyReleaseAt = this.scene.time.now + telegraphMs(k);
      this.setMode("storyCast", telegraphMs(k) + duration + 100);
      this.story?.start(k, player); return;
    }
    switch (kind) {
      case "slam":
        this.startSlam(player);
        break;
      case "charge":
        this.startCharge(player);
        break;
      case "volley":
        this.startVolley();
        break;
      case "ring":
        this.startRing();
        break;
      case "zones":
        this.startZones(player);
        break;
      case "summon":
        this.startSummon();
        break;
      /* ---- v4.1.4 — 보스별 시그니처 패턴 ---- */
      case "spiral":
        this.startSpiral();
        break;
      case "beam":
        this.startBeam(player);
        break;
      case "blink":
        this.startBlink();
        break;
      case "quake":
        this.startQuake();
        break;
      case "counter":
        this.startCounter();
        break;
      /* ---- vc153 — 스바르트알프헤임 보스 개편 (애니 사양표 상태머신) ---- */
      case "greenslash":
        this.startGreenSlash(player);
        break;
      case "vanish":
        this.startVanish();
        break;
      case "shieldcast":
        this.startShieldCast();
        break;
      /* ---- vc142 (#6) — 보스 고유 VX 패턴 (유저 에셋 FX) ---- */
      case "firepillars":
      case "frostnova":
      case "thunderfall":
      case "poisonfield":
      case "holymantle":
      case "crystalburst":
      case "blinkslash":
      case "magicburst":
      case "portalteleport":
        this.startVx(kind, player);
        break;
    }
  }

  private setMode(m: BossMode, t: number) {
    this.mode = m;
    this.modeTimer = t;
  }

  /* ---------- 스킬 1: 강타 (AOE) ---------- */

  private startSlam(player: PlayerLike2) {
    this.setMode("slamTele", telegraphMs("slam"));
    this.squash(-0.07, 0.11); // v1.4.9 — 강타 예고: 몸을 뒤로 젖히며 기모으기
    // 텔레그래프: 플레이어 현재 위치에 붉은 원 — 외부 에셋 링(Kenney CC0) 적색 틴트
    const ring = this.scene.add
      .image(player.x, player.y, "ring")
      .setDepth(5)
      .setTint(0xff5a5a)
      .setAlpha(0.4)
      .setScale(0.2);
    this.teleRings.push(ring);
    this.teleRing = ring;
    this.scene.tweens.add({ targets: ring, scale: 1, alpha: 0.9, duration: 720 });
    this.setTint(0xffb0a0);
  }

  private doSlam(player: PlayerLike2) {
    this.setTint(0xffffff);
    this.squash(0.14, -0.14); // v1.4.9 — 강타 착지 임팩트
    const ring = this.teleRing;
    if (ring) {
      const tx = ring.x;
      const ty = ring.y;
      this.scene.impactFX.shake(90, 0.006);
      this.scene.spawnSlamBurst(tx, ty);
      this.scene.spawnCrack(tx, ty);
      /* vc142 (#7) — hv2_crater 지균 데칼 제거: 가산 블렌드용 순흑 텍스처가 NORMAL로 그려져
       * "검은 네모가 터지는" 이질 연출이 됨 (유저 지시 — 삭제). 대신 두꺼운 임팩트 링으로 착지감 유지 */
      this.scene.driveFx?.shockHeavy(tx, ty, 0xffc890, 1.15);
      if (Phaser.Math.Distance.Between(tx, ty, player.x, player.y) < 118) {
        const dir = new Phaser.Math.Vector2(player.x - tx, player.y - ty).normalize();
        player.takeDamage(Math.round(this.def.atk * 1.35), dir, 0.5, this.chaos ? 0.12 : 0); // v3.0.6 — 관통 + 강타 maxHP % 하한
      }
      this.scene.tweens.add({
        targets: ring,
        alpha: 0,
        duration: 160,
        onComplete: () => ring.destroy(),
      });
      this.teleRings = this.teleRings.filter((r) => r !== ring);
      this.teleRing = null;
    }
    this.clearTint();
    this.endAttack(1500);
  }

  /* ---------- 스킬 2: 돌진 ---------- */

  private startCharge(player: PlayerLike2) {
    void player;
    // v4.1.4 — 돌진 연쇄: def.chargeChain(fenrir 2 / skoll 2+blink, 카오스 +1, 상한 3)
    this.chargeChainLeft = Math.min(3, (this.def.chargeChain ?? 1) - 1 + (this.chaos ? 1 : 0));
    /* P7b — 돌진 예고를 bossPhases 기준(850ms)으로. 종전 550ms 는 range 하한(600) 미만이었다.
     *  돌진은 유도형이라 예고가 짧으면 사실상 피할 수 없다 — 바닥에 진행선을 깐다. */
    this.setMode("chargeTele", telegraphMs("charge"));
    this.vxWarnRing(this.x, this.y, 0xff9060, 1.25, telegraphMs("charge") * 0.85);
  }

  /* ---------- 스킬 3: 투사체 ---------- */

  private startVolley() {
    /* P7b — 종전 10ms 는 사실상 예고 없음(즉발)이라 "위험 공격 사전 예고"가 없었다.
     *  bossPhases.TELEGRAPH_MS 기준값을 쓰고, 그 시간만큼 조준 자세를 취한다. */
    this.setMode("volley", telegraphMs("volley"));
    this.setTint(0x88a0ff);
    this.squash(-0.05, 0.07); // v1.4.9 — 발사 전 들이마시기
    /* P7b — 조준 예고 링 (즉발 → 예고 후 발사). 매 프레임 생성 아님, 패턴당 1회. */
    this.vxWarnRing(this.x, this.y, 0x88a0ff, 1.05, telegraphMs("volley") * 0.85);
    {
      const e = this.elem;
      const ck = e === "ice" ? "hv2_snow" : e === "fire" ? "mg_fire" : "hv2_glow";
      this.bossFx(ck, this.x, this.y - 30, { tint: e === "fire" ? 0xff9a5a : 0xffffff, scale: 0.55, alpha: 0.85, dur: 300, depth: 20 });
    }
    /* 예고가 끝난 뒤 실제 발사 — 타이머 시작을 예고 시간만큼 미룬다. */
    this.scene.time.delayedCall(telegraphMs("volley"), () => this.alive && this.fireVolley());
  }

  /** 실제 부채꼴 발사 (P7b — startVolley 의 예고가 끝난 뒤 호출) */
  private fireVolley() {
  /** 페이즈별 탄 수 증가 (1:5 / 2:7 / 3:12) — v3.0.6: 보스 강화 */
    this.volleyCount = this.phase === 1 ? 5 : this.phase === 2 ? 7 : 12;
    let remaining = this.volleyCount;
    this.volleyTimer?.remove();
    this.volleyTimer = this.scene.time.addEvent({
      delay: 130,
      repeat: this.volleyCount - 1,
      callback: () => {
        if (!this.alive) return;
        const target = this.scene.playerRef;
        if (!target) return;
        const base = Math.atan2(target.y - this.y, target.x - this.x);
        // 부채꼴 발사 — 페이즈가 오를수록 좁고 촘촘
        const spread = this.phase === 3 ? 0.14 : 0.22;
        const n = this.phase >= 2 ? 2 : 1;
        for (let k = 0; k < n; k++) {
          const a = base + (k === 0 ? 0 : k % 2 === 1 ? spread * k : -spread * (k - 1));
          this.fireOrb(a, 200);
        }
        this.scene.sfxSwing();
        remaining--;
        if (remaining <= 0) {
          this.clearTint();
          this.endAttack(1500);
        }
      },
    });
  }

  /* ---------- 스킬 4: 원형 탄막 (링) ---------- */

  private startRing() {
    /* P7b — 420ms 는 range 하한(600) 미만이었다. 원형 탄막은 사방으로 퍼져
     *  "어디로 피할지" 판단할 시간이 필요하므로 850ms 로 늘린다. */
    this.setMode("ringTele", telegraphMs("ring"));
    this.setTint(0xffe08a);
    this.squash(-0.05, 0.07); // v1.4.9 — 탄막 예고 기모으기
    this.vxWarnRing(this.x, this.y, 0xffe08a, 1.5, telegraphMs("ring") * 0.85);
  }

  private doRing() {
    this.clearTint();
    // 보스를 중심으로 방사형 탄막 — 페이즈 3은 2연속 파동 (v3.0.6: 탄수 상향 12/16/20)
    const waves = this.phase === 3 ? 2 : 1;
    const count = this.phase === 1 ? 12 : this.phase === 2 ? 16 : 20;
    for (let w = 0; w < waves; w++) {
      this.scene.time.delayedCall(w * 340, () => {
        if (!this.alive) return;
        this.squash(0.06, -0.06); // v1.4.9 — 파동 발사 펄스
        const offset = w * 0.19; // 두 번째 파동은 틀어진 각도 — 틈새 사격
        for (let i = 0; i < count; i++) {
          this.fireOrb(offset + (Math.PI * 2 * i) / count, 165 + w * 25, Math.round(this.def.atk * 0.5));
        }
        this.scene.sfxSwing();
      });
    }
    this.endAttack(1600);
  }

  /* ---------- 스킬 5: 바닥 장판 (존스) ---------- */

  private startZones(player: PlayerLike2) {
    this.setMode("zonesTele", telegraphMs("zones"));
    this.setTint(0xffa060);
    this.squash(-0.06, 0.09); // v1.4.9 — 장판 시전 기모으기
    // 플레이어 위치 중심 3개 장판 예고 — 1개는 보스 근처 무작위
    const spots: [number, number][] = [
      [player.x, player.y],
      [
        Phaser.Math.Clamp(player.x + Phaser.Math.Between(-220, 220), 60, this.scene.stageW - 60),
        Phaser.Math.Clamp(player.y + Phaser.Math.Between(-180, 180), 60, this.scene.stageH - 60),
      ],
      [
        Phaser.Math.Clamp(this.x + Phaser.Math.Between(-160, 160), 60, this.scene.stageW - 60),
        Phaser.Math.Clamp(this.y + Phaser.Math.Between(-140, 140), 60, this.scene.stageH - 60),
      ],
    ];
    for (const [zx, zy] of spots) {
      const ring = this.scene.add
        .image(zx, zy, "ring")
        .setDepth(5)
        .setTint(0xff8848)
        .setAlpha(0.35)
        .setScale(0.2);
      this.zoneRings.push(ring);
      this.scene.tweens.add({ targets: ring, scale: 0.82, alpha: 0.9, duration: 820 });
    }
  }

  private doZones(player: PlayerLike2) {
    this.clearTint();
    this.scene.impactFX.shake(110, 0.005);
    for (const ring of this.zoneRings) {
      this.scene.spawnSlamBurst(ring.x, ring.y);
      /* v1.4.11 — 장판 폭발: 결정 파편 + MG 폭발 퍼프 (hv2_crystal·mg_explode) */
      this.scene.driveFx?.crystalPop(ring.x, ring.y, 0xff9a68, 3);
      this.bossFx("mg_explode", ring.x, ring.y - 6, { tint: 0xff8848, scale: 0.9, alpha: 0.95, dur: 340, depth: 25 });
      if (Phaser.Math.Distance.Between(ring.x, ring.y, player.x, player.y) < 95) {
        const dir = new Phaser.Math.Vector2(player.x - ring.x, player.y - ring.y).normalize();
        player.takeDamage(Math.round(this.def.atk * 0.9), dir);
      }
      /* vc264 (지시 #9) — 폭발한 자리에 **불 장판**이 남는다.
       *  [왜] 종전엔 링을 alpha 0 으로 지워(=destroy) 화면에 흔적이 없었다.
       *  "장판이 생기고 다른 공격이 없다"는 지적의 직접 원인 — 폭발만 있고 지속 장판이 0이었다. */
      this.dropField({ x: ring.x, y: ring.y }, "fire", 92, 3200, Math.round(this.def.atk * 0.22));
      this.scene.tweens.add({ targets: ring, alpha: 0, duration: 150, onComplete: () => ring.destroy() });
    }
    this.zoneRings = [];
    this.endAttack(1500);
  }

  /* ---------- 스킬 6: 소환 ---------- */

  /* ---------- v1.4.11 — Drive 신규 팩 이펙트 헬퍼 (hv2_·mg_ 시리즈 — 텍스처 없으면 무시, 구버전 호환) ---------- */

  /** 보스 이펙트 공용: 텍스처 존재 가드 + ADD 블렌드 페이드인→아웃 1회성 이미지 */
  private bossFx(key: string, x: number, y: number, opt: { tint?: number; scale?: number; alpha?: number; dur?: number; depth?: number } = {}) {
    if (!this.scene.textures.exists(key)) return;
    const s = opt.scale ?? 1;
    const im = this.scene.add.image(x, y, key)
      .setDepth(opt.depth ?? 9)
      .setBlendMode(Phaser.BlendModes.ADD)
      .setTint(opt.tint ?? 0xffffff)
      .setScale(s * 0.6)
      .setAlpha(0);
    this.scene.tweens.add({ targets: im, alpha: opt.alpha ?? 0.9, scaleX: s, scaleY: s, duration: 130, ease: "Quad.out" });
    this.scene.tweens.add({ targets: im, alpha: 0, duration: opt.dur ?? 260, delay: (opt.dur ?? 260) * 0.4, onComplete: () => im.destroy() });
  }

  /** 소환 채널링 — Hovl 룬 마법진 회전 (보스 발밑) */
  private summonFx(tint = 0xc070ff, dur = 620) {
    if (!this.scene.textures.exists("hv2_magiccircle")) return;
    const c = this.scene.add.image(this.x, this.y + 8, "hv2_magiccircle")
      .setDepth(8)
      .setBlendMode(Phaser.BlendModes.ADD)
      .setTint(tint)
      .setScale(0.55)
      .setAlpha(0.9);
    this.scene.tweens.add({ targets: c, rotation: Math.PI * 2, duration: dur * 2, repeat: -1 });
    this.scene.tweens.add({ targets: c, alpha: 0, scale: 0.8, duration: dur, delay: dur * 0.4, onComplete: () => c.destroy() });
  }

  private startSummon() {
    this.setMode("summonTele", telegraphMs("summon"));
    this.setTint(0xc070ff);
    this.squash(-0.07, 0.12); // v1.4.9 — 소환 주문 채널링
    this.summonFx(0xc070ff, 620); // v1.4.11 — 룬 마법진 (hv2_magiccircle)
  }

  private doSummon() {
    this.clearTint();
    const key = this.def.summonKey;
    if (key) {
      this.scene.requestSummon(key, this.phase === 3 ? 2 : 1, this.x, this.y);
      this.scene.spawnBurstAt(this.x, this.y, 16, 0xc070ff);
      this.bossFx("hv2_crystal", this.x, this.y - 6, { tint: 0xc070ff, scale: 0.9, dur: 320 }); // v1.4.11 — 결정 파편
      this.scene.showBanner(`${this.def.name}가 권속을 부른다!`);
    }
    this.endAttack(1700);
  }

  /* ================= vc142 (#6) — 보스 고유 VX 패턴 (유저 에셋팩 FX) =================
   * 보스마다 전부 다른 공격: 수르트=화염기둥 추적, 니드호그/요르문간드=맹독 장판,
   * 베헤모스/스콜=빙결 신성, 나그라파르=뇌우, 아부디토스=성역, 심연군주/베오르드=결정 산개,
   * 가름=점멸 참격. 전부 유저 제공 UNI VFX·Hovl·Cartoon FX 텍스처 크롭분으로 연출한다. */

  /** VX 플립북 1회 재생 (텍스처/애니 부재 시 무시 — 구버전 캐시 호환) */
  private vxAnimAt(x: number, y: number, anim: string | null, tex: string, tint: number, scale = 1, rot = 0) {
    if (!this.scene.textures.exists(tex)) return;
    if (anim && this.scene.anims.exists(anim)) {
      const s = this.scene.add.sprite(x, y, tex, 0).setDepth(24).setBlendMode(Phaser.BlendModes.ADD).setTint(tint).setScale(scale * 0.55).setRotation(rot);
      s.play(anim);
      s.once(Phaser.Animations.Events.ANIMATION_COMPLETE, () => s.destroy());
      return s;
    }
    return this.bossFx(tex, x, y, { tint, scale, alpha: 0.92, dur: 320, depth: 24 });
  }

  /** VX 예고 링 — 반투명 확장 링 (피해 판정 전 위치 예고)
   *  vc145 (#15) — ADD 블렌드 강제: vx_* 팩은 가산용(흑색 배경) 텍스처라 NORMAL로 그리면
   *  검은 네모가 노출된다 (hv2_crater와 동일 사고). */
  private vxWarnRing(x: number, y: number, tint: number, target = 1.0, dur = 720) {
    if (!this.scene.textures.exists("vx_ring")) return null;
    const r = this.scene.add.image(x, y, "vx_ring").setDepth(6).setBlendMode(Phaser.BlendModes.ADD).setTint(tint).setAlpha(0.0).setScale(target * 0.3);
    this.scene.tweens.add({ targets: r, alpha: 0.75, scaleX: target, scaleY: target, duration: dur, ease: "Quad.out" });
    this.scene.time.delayedCall(dur + 120, () => {
      this.scene.tweens.add({ targets: r, alpha: 0, duration: 160, onComplete: () => r.destroy() });
    });
    return r;
  }

  /** VX 예고 단계 — 종류별 예고 이펙트 + 몸 색 변화 (예고 후 doVx)
   *  P7b — 종전 전 패턴 일괄 780ms 였다. 이제 `bossPhases.TELEGRAPH_MS` 의 종류별 값을 쓴다
   *  (holymantle 1100 · magicburst 1000 처럼 큰 공격은 더 길게, blinkslash 720 은 짧게). */
  private startVx(kind: BossAttackKind, player: PlayerLike2) {
    this.vxKind = kind;
    this.vxStep = 0;
    this.setMode("vxTele", telegraphMs(kind));
    switch (kind) {
      case "firepillars": // 수르트 — 화염 기둥이 플레이어를 3회 추적
        this.setTint(0xffb090);
        this.vxWarnRing(player.x, player.y, 0xff7a3a, 0.95);
        break;
      case "frostnova": // 눈보라의 거수/얼음 봉황 — 확장 빙결 신성
        this.setTint(0x9ad8ff);
        this.bossFx("vx_circlehazy", this.x, this.y + 8, { tint: 0x9ad8ff, scale: 1.7, alpha: 0.7, dur: 700, depth: 8 });
        this.vxWarnRing(this.x, this.y, 0x8ad4ff, 2.0);
        break;
      case "thunderfall": // 나그라파르 — 추적 낙뢰 4연속
        this.setTint(0xffe08a);
        this.bossFx("vx_glowball", player.x, player.y, { tint: 0xffe08a, scale: 1.2, alpha: 0.75, dur: 740, depth: 8 });
        break;
      case "poisonfield": // 니드호그/요르문간드 — 맹독 장판 3개
        this.setTint(0x9aff9a);
        this.bossFx("vx_puddle", player.x, player.y, { tint: 0x7dff9a, scale: 1.1, alpha: 0.45, dur: 740, depth: 7 });
        break;
      case "holymantle": // 아부디토스 — 마룡 성역 대폭발
        this.setTint(0xffd0d8);
        this.bossFx("vx_magiccircle", this.x, this.y + 8, { tint: 0xff3a6a, scale: 1.8, alpha: 0.85, dur: 760, depth: 8 });
        this.vxWarnRing(this.x, this.y, 0xff3a6a, 2.35);
        break;
      case "crystalburst": // 심연의 군주/베오르드 — 8방향 결정 산개
        this.setTint(0x9ad0ff);
        this.bossFx("vx_crystal", this.x, this.y - 20, { tint: 0x8ad4ff, scale: 1.0, alpha: 0.85, dur: 720, depth: 9 });
        break;
      case "blinkslash": // 가름 — 점멸 3연 참격
        this.setTint(0xa0ffd8);
        this.bossFx("vx_slash", player.x, player.y - 12, { tint: 0x8affc0, scale: 1.0, alpha: 0.8, dur: 740, depth: 20 });
        break;
      /* ── vc264 (지시 #9 "또다른 공격들 없음??") — 죽어 있던 패턴 2개 부활 ──────
       * [버그] 아래 둘은 stages.ts 의 보스 풀(abysslord p3 등)에 **등록되어 있는데**
       *        startVx 에 case 가 없어 default 로 떨어져 vxKind=null → 보스가 그냥 idle.
       *        특히 portalteleport 는 doVx 에 완전한 구현이 있는데도 도달 불가였다.
       *        (doVx 의 default 가 endAttack 만 하므로 "공격 없는 턴"처럼 보였다) */
      case "magicburst": // 심연의 군주 — 마력 폭발 (전방위 탄막)
        this.setTint(0xc9a6ff);
        this.bossFx("vx_magiccircle", this.x, this.y + 8, { tint: 0xb07dff, scale: 1.6, alpha: 0.8, dur: 760, depth: 8 });
        this.vxWarnRing(this.x, this.y, 0xb07dff, 1.9);
        break;
      case "portalteleport": // 아크 — 포탈 2기 소환 후 순간이동 + 녹색 참격
        this.setTint(0x8ad4ff);
        this.bossFx("hv2_magiccircle2", this.x, this.y + 8, { tint: 0x8ad4ff, scale: 1.3, alpha: 0.85, dur: 700, depth: 8 });
        break;
      default:
        this.vxKind = null;
        this.mode = "idle";
    }
  }

  /**
   * vc264 (지시 #9 "이렇게 장판이 생기고 또다른 공격들 없음??")
   * 보스가 **지속 장판**을 남긴다.
   *
   * [왜 필요했나] 전수 조사 결과 `spawnField({owner:"enemy"})` 호출이 코드베이스에
   * **단 한 곳**(Enemy.ts 의 사망 드롭)뿐이었다. 보스는 장판을 만들지 않았고,
   * `zones` 패턴조차 링을 띄웠다가 **즉시 폭발 후 destroy** 하는 1회성이라
   * 화면에 남는 장판이 없었다. 그래서 "장판 하나 생기고 다른 공격 없음"으로 보였다.
   *
   * [설계] 판정/렌더는 WorldScene.spawnField 하나에 그대로 맡긴다(중복 구현 금지).
   *  여기서는 보스 위치·플레이어 위치 중 어디에 깔지만 결정한다.
   *
   * @param at       "player" 추적 | "boss" 보스 발밑 | {x,y} 지정
   * @param kind     poison / fire / light / time (WorldScene 장판 종류 그대로)
   * @param radius   반경(px). 보스 패턴은 보통 90~170
   * @param dur      지속(ms)
   * @param dps      초당 피해
   */
  private dropField(
    at: "player" | "boss" | { x: number; y: number },
    kind: "poison" | "fire" | "light" | "time",
    radius: number,
    dur: number,
    dps: number,
  ): void {
    const p = at === "player" ? this.scene.player
      : at === "boss" ? { x: this.x, y: this.y }
      : at;
    if (!p) return;
    this.scene.spawnField({
      x: p.x, y: p.y, radius, dur, dps, kind, owner: "enemy",
    });
  }

  /** VX 실행 단계 — 종류별 판정/연출 */
  private doVx(player: PlayerLike2) {
    const kind = this.vxKind;
    this.vxKind = null;
    this.clearTint();
    if (!kind) { this.endAttack(900); return; }
    const atk = this.def.atk;
    const tint = this.def.orbTint;
    switch (kind) {
      case "firepillars": {
        /* 수르트 — 플레이어 추적 화염 기둥 3연속 (vx_expcore 분출 + vx_fire 잔불) */
        this.setMode("vxCast", 2200);
        let n = 0;
        const strike = () => {
          if (!this.alive || player.hp <= 0 || n >= 3) { this.endAttack(1100); return; }
          n++;
          const tx = player.x, ty = player.y;
          this.vxWarnRing(tx, ty, 0xff7a3a, 0.9, 420);
          this.scene.time.delayedCall(420, () => {
            if (!this.alive) return;
            this.vxAnimAt(tx, ty, "vx-expcore", "vx_expcore", tint, 1.5);
            this.vxAnimAt(tx, ty - 18, "vx-fire", "vx_fire", 0xffa05a, 1.35);
            this.scene.spawnSlamBurst(tx, ty);
            /* vc142 (#9) — 3D 빛기둥 + 폭발 (Three.js 오버레이) */
            this.scene.vfx3dFx("pillar", tx, ty, tint, 1.2);
            this.scene.impactFX.shake(70, 0.004);
            if (Phaser.Math.Distance.Between(tx, ty, player.x, player.y) < 92) {
              const dir = new Phaser.Math.Vector2(player.x - tx, player.y - ty).normalize();
              player.takeDamage(Math.round(atk * 1.15), dir, 0.5, this.chaos ? 0.10 : 0);
            }
            /* vc264 (지시 #9) — 기둥이 꺼진 자리에 **잔불 장판**을 남긴다.
             *  종전엔 폭발 이펙트만 사라지고 바닥에 아무것도 안 남아
             *  "장판이 어디 있냐"는 지적을 받았다. 3.5초 지속, 밟으면 도트. */
            this.dropField({ x: tx, y: ty }, "fire", 78, 3500, Math.round(atk * 0.30));
            this.scene.time.delayedCall(230, strike);
          });
        };
        strike();
        break;
      }
      case "frostnova": {
        /* 눈보라의 거수/얼음 봉황 — 2겹 확장 링 + 눈송이 산개 (200px 판정) */
        this.setMode("vxCast", 900);
        const nova = (delay: number, dmgMul: number, radius: number) => {
          this.scene.time.delayedCall(delay, () => {
            if (!this.alive) return;
            const g = this.scene.add.image(this.x, this.y, "vx_ring").setDepth(23).setBlendMode(Phaser.BlendModes.ADD).setTint(0x9ad8ff).setScale(0.4).setAlpha(0.95);
            this.scene.tweens.add({ targets: g, scale: radius / 38, alpha: 0, duration: 420, ease: "Quad.out", onComplete: () => g.destroy() });
            /* vc142 (#9) — 3D 확장 링 (빙결 신성) */
            this.scene.vfx3dFx("ring", this.x, this.y, 0x9ad8ff, 1.6);
            for (let i = 0; i < 10; i++) {
              const a = (Math.PI * 2 * i) / 10 + Math.random() * 0.4;
              const sx = this.scene.add.image(this.x, this.y, "vx_snow").setDepth(22).setBlendMode(Phaser.BlendModes.ADD).setTint(0xbde8ff).setScale(0.5 + Math.random() * 0.4);
              this.scene.tweens.add({ targets: sx, x: this.x + Math.cos(a) * radius * 1.15, y: this.y + Math.sin(a) * radius * 1.15, alpha: 0, scale: 0.2, duration: 520, ease: "Quad.out", onComplete: () => sx.destroy() });
            }
            this.scene.impactFX.shake(90, 0.005);
            if (Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y) < radius) {
              const dir = new Phaser.Math.Vector2(player.x - this.x, player.y - this.y).normalize();
              player.takeDamage(Math.round(atk * dmgMul), dir, 0.5, this.chaos ? 0.09 : 0);
            }
          });
        };
        nova(60, 0.85, 200);
        nova(300, 0.6, 205); // 2겹 — 첫 링 회피 후 이중 판정
        this.scene.sfxRoar();
        this.endAttack(1300);
        break;
      }
      case "thunderfall": {
        /* 나그라파르 — 추적 낙뢰 4연속 (vx-bolt 낙하 + vx_elec 착탄) */
        this.setMode("vxCast", 2500);
        let n = 0;
        const drop = () => {
          if (!this.alive || player.hp <= 0 || n >= 4) { this.endAttack(1000); return; }
          n++;
          const tx = player.x, ty = player.y;
          this.scene.time.delayedCall(340, () => {
            if (!this.alive) return;
            this.vxAnimAt(tx, ty - 80, "vx-bolt", "vx_bolt", 0xffe08a, 1.15);
            this.scene.time.delayedCall(120, () => {
              if (!this.alive) return;
              this.vxAnimAt(tx, ty, "vx-elec", "vx_elec", 0xfff2c0, 1.2);
              this.scene.spawnBurstAt(tx, ty, 8, 0xffe08a);
              /* vc142 (#9) — 3D 낙뢰 빛기둥 */
              this.scene.vfx3dFx("pillar", tx, ty, 0xffe08a, 1.0);
              this.scene.impactFX.shake(60, 0.004);
              if (Phaser.Math.Distance.Between(tx, ty, player.x, player.y) < 86) {
                const dir = new Phaser.Math.Vector2(player.x - tx, player.y - ty).normalize();
                player.takeDamage(Math.round(atk * 0.95), dir, 0.5, this.chaos ? 0.09 : 0);
              }
              /* vc264 (지시 #9) — 낙뢰 착탄점에 감전 장판(2.8초). */
              this.dropField({ x: tx, y: ty }, "light", 70, 2800, Math.round(atk * 0.26));
              this.scene.time.delayedCall(220, drop);
            });
          });
        };
        drop();
        break;
      }
      case "poisonfield": {
        /* 니드호그/요르문간드 — 맹독 장판 3개 (6초 지속, 밟으면 도트) */
        this.setMode("vxCast", 700);
        const until = this.scene.time.now + 6000;
        for (let i = 0; i < 3; i++) {
          const ang = Math.random() * Math.PI * 2;
          const r = i === 0 ? 0 : Phaser.Math.Between(70, 150);
          const zx = Phaser.Math.Clamp(player.x + Math.cos(ang) * r, 60, this.scene.stageW - 60);
          const zy = Phaser.Math.Clamp(player.y + Math.sin(ang) * r, 60, this.scene.stageH - 60);
          if (!this.scene.textures.exists("vx_puddle")) break;
          /* vc145 (#15) — ADD 블렌드 강제 (검은 네모 제거 — vxWarnRing과 동일 사유) */
          const img = this.scene.add.image(zx, zy, "vx_puddle").setDepth(4).setBlendMode(Phaser.BlendModes.ADD).setTint(0x5adf7a).setAlpha(0).setScale(1.5);
          this.scene.tweens.add({ targets: img, alpha: 0.42, duration: 260 });
          this.scene.time.delayedCall(6000, () => {
            if (!img.active) return;
            this.scene.tweens.add({ targets: img, alpha: 0, duration: 420, onComplete: () => img.destroy() });
          });
          this.poisonZones.push({ x: zx, y: zy, until, img, last: 0 });
        }
        this.vxAnimAt(player.x, player.y, "vx-petal", "vx_petal", 0x7dff9a, 0.9);
        this.scene.spawnBurstAt(player.x, player.y, 10, 0x7dff9a);
        this.endAttack(1100);
        break;
      }
      case "holymantle": {
        /* 아부디토스 — 마룡 성역: 560ms 기믹 후 240px 대폭발 (vx_aura+vx_magiccircle) */
        this.setMode("vxCast", 800);
        this.bossFx("vx_magiccircle", this.x, this.y + 8, { tint, scale: 2.2, alpha: 0.9, dur: 620, depth: 8 });
        this.bossFx("vx_aura", this.x, this.y - 6, { tint: 0xffffff, scale: 1.6, alpha: 0.8, dur: 620, depth: 22 });
        this.scene.time.delayedCall(560, () => {
          if (!this.alive) return;
          const g = this.scene.add.image(this.x, this.y, "vx_ring").setDepth(23).setBlendMode(Phaser.BlendModes.ADD).setTint(tint).setScale(0.5).setAlpha(0.95);
          this.scene.tweens.add({ targets: g, scale: 6.4, alpha: 0, duration: 460, ease: "Quad.out", onComplete: () => g.destroy() });
          this.vxAnimAt(this.x, this.y, "vx-expcore", "vx_expcore", 0xffffff, 2.0);
          /* vc142 (#9) — 마룡 성역 대폭발 (3D) */
          this.scene.vfx3dFx("boom", this.x, this.y, tint, 2.2);
          this.scene.impactFX.shake(220, 0.009);
          if (Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y) < 244) {
            const dir = new Phaser.Math.Vector2(player.x - this.x, player.y - this.y).normalize();
            player.takeDamage(Math.round(atk * 1.3), dir, 0.5, this.chaos ? 0.12 : 0);
          }
        });
        this.endAttack(1500);
        break;
      }
      case "magicburst": {
        /* vc264 (지시 #9) — 심연의 군주 마력 폭발.
         *  startVx 에는 있었지만 doVx 에 case 가 없어 default(endAttack)로 끝났다.
         *  3연 폭발: 보스 중심 1회 → 플레이어 추적 2회. 각 폭발은 반경 150 / 130. */
        this.setMode("vxCast", 1300);
        const burst = (bx: number, by: number, radius: number, dmgMul: number, delay: number) => {
          this.scene.time.delayedCall(delay, () => {
            if (!this.alive) return;
            this.scene.vfx3dFx("boom", bx, by, 0xb07dff, 1.6);
            this.scene.spawnShockwave(bx, by, 0xb07dff, 1.4, 340, 0.75);
            this.scene.impactFX.shake(90, 0.004);
            if (Phaser.Math.Distance.Between(bx, by, player.x, player.y) < radius) {
              const dir = new Phaser.Math.Vector2(player.x - bx, player.y - by).normalize();
              player.takeDamage(Math.round(atk * dmgMul), dir, 0.45, this.chaos ? 0.1 : 0);
            }
            /* vc264 (지시 #9) — 폭발 자리에 마력 장판(3초). */
            this.dropField({ x: bx, y: by }, "time", 96, 3000, Math.round(atk * 0.24));
          });
        };
        burst(this.x, this.y, 150, 0.9, 120);
        burst(player.x, player.y, 130, 0.7, 620);
        burst(player.x, player.y, 130, 0.7, 1040);
        this.endAttack(1500);
        break;
      }
      case "crystalburst": {
        /* 심연의 군주/베오르드 — 결정 파편 8방향 산개 (vx_crystal 비행 판정) */
        this.setMode("vxCast", 1100);
        for (let i = 0; i < 8; i++) {
          const ang = (Math.PI * 2 * i) / 8 + Math.random() * 0.3;
          if (!this.scene.textures.exists("vx_crystal")) break;
          const img = this.scene.add.image(this.x, this.y - 10, "vx_crystal").setDepth(22).setBlendMode(Phaser.BlendModes.ADD).setTint(0x8ad4ff).setScale(0.38);
          let hit = false;
          this.scene.tweens.add({
            targets: img,
            x: this.x + Math.cos(ang) * 265, y: this.y + Math.sin(ang) * 265,
            scale: 0.68, alpha: 0.9, duration: 620, ease: "Quad.out",
            onUpdate: () => {
              if (hit || !img.active) return;
              if (Phaser.Math.Distance.Between(img.x, img.y, player.x, player.y) < 42) {
                hit = true;
                player.takeDamage(Math.round(atk * 0.7), new Phaser.Math.Vector2(Math.cos(ang), Math.sin(ang)), 0.4, 0);
                img.destroy();
              }
            },
            onComplete: () => img.destroy(),
          });
        }
        this.scene.sfxSwing();
        this.endAttack(1250);
        break;
      }
      case "blinkslash": {
        /* 가름 — 점멸 3연 참격 (보스가 플레이어 주위로 순간이동하며 벤다) */
        this.setMode("vxCast", 1500);
        let n = 0;
        const swing = () => {
          if (!this.alive || player.hp <= 0 || n >= 3) { this.endAttack(950); return; }
          n++;
          const ang = Math.random() * Math.PI * 2;
          const nx = Phaser.Math.Clamp(player.x + Math.cos(ang) * 72, 60, this.scene.stageW - 60);
          const ny = Phaser.Math.Clamp(player.y + Math.sin(ang) * 72, 60, this.scene.stageH - 60);
          this.vxAnimAt(this.x, this.y - 10, "vx-smoke", "vx_smoke", 0x8affc0, 0.9);
          this.setPosition(nx, ny);
          const rot = Math.random() * Math.PI - Math.PI / 2;
          this.vxAnimAt(player.x, player.y - 12, null, "vx_slash", 0x8affc0, 1.25, rot);
          this.scene.impactFX.shake(60, 0.004);
          this.scene.sfxSwing();
          if (Phaser.Math.Distance.Between(nx, ny, player.x, player.y) < 118) {
            const dir = new Phaser.Math.Vector2(player.x - nx, player.y - ny).normalize();
            player.takeDamage(Math.round(atk * 0.95), dir, 0.5, this.chaos ? 0.09 : 0);
          }
          this.scene.time.delayedCall(320, swing);
        };
        swing();
        break;
      }
      case "portalteleport": {
        /* vc153 사양표 ⑦ PortalTeleport(Once) — 포탈 2기 소환 → 현재 위치 소멸 → 다른 포탈에서 재등장 + 녹색 참격 */        this.setMode("vxCast", 1250);
        const ang = Math.random() * Math.PI * 2;
        const d = Phaser.Math.Between(220, 330);
        const px = Phaser.Math.Clamp(player.x + Math.cos(ang) * d, 60, this.scene.stageW - 60);
        const py = Phaser.Math.Clamp(player.y + Math.sin(ang) * d, 60, this.scene.stageH - 60);
        /* 출발/도착 포탈 — 룬 마법진 + 확장 링 */
        this.bossFx("hv2_magiccircle2", this.x, this.y + 8, { tint, scale: 1.4, alpha: 0.9, dur: 640, depth: 8 });
        this.bossFx("hv2_magiccircle2", px, py + 8, { tint: 0x8ad4ff, scale: 1.4, alpha: 0.9, dur: 900, depth: 8 });
        this.scene.vfx3dFx("ring", px, py, 0x8ad4ff, 1.5);
        this.scene.sfxDash();
        /* 전이 — Vanish 재활용 (투명 → 재배치 → 포탈 팝) */
        this.scene.time.delayedCall(560, () => {
          if (!this.alive) return;
          this.setAlpha(0);
          this.scene.spawnBurstAt(this.x, this.y, 12, tint);
        });
        this.scene.time.delayedCall(1150, () => {
          if (!this.alive) return;
          this.setPosition(px, py);
          this.setAlpha(1);
          this.scene.spawnBurstAt(px, py, 16, 0x8ad4ff);
          this.squash(0.1, -0.1);
          this.setBossAnim(`${this.visualKey || this.def.tex}-idle`);
          this.endAttack(950);
          /* 재등장 즉시 사양표 ③ GreenSlash로 연계 */
          this.startGreenSlash(player);
        });
        break;
      }
      default:
        this.endAttack(900);
    }
  }

  /** 독 장판 판정 (tick에서 호출 — 밟으면 0.7초마다 도트) */
  private tickPoisonZones(player: PlayerLike2) {
    if (this.poisonZones.length === 0) return;
    const now = this.scene.time.now;
    for (const z of this.poisonZones) {
      if (!z.img.active) continue;
      if (now > z.until) continue;
      if (now - z.last > 700 && Phaser.Math.Distance.Between(z.x, z.y, player.x, player.y) < 80) {
        z.last = now;
        player.takeDamage(Math.max(1, Math.round(this.def.atk * 0.3)), new Phaser.Math.Vector2(0, 1), 0.3, 0);
        this.vxAnimAt(player.x, player.y, null, "vx_splat", 0x7dff9a, 0.7);
      }
    }
    this.poisonZones = this.poisonZones.filter((z) => now <= z.until || z.img.active === false);
  }

  /* ================= v4.1.4 — 보스별 시그니처 패턴 ================= */

  /* ---------- 나선 탄막 (behemoth 눈보라 / abysslord 심연 / abudditos 종언) ----------
   * 보스를 중심으로 회전하는 다중 나선 탄막 — 틈을 읽고 돌파하는 탄막 게임식 패턴 */
  private startSpiral() {
    /* P7b — 종전 "volley", 10 은 예고 없는 즉발이었다(나선은 탄이 화면을 채워 회피 불가).
     *  나선 전용 예고 모드로 바꿔 700ms 동안 조준 자세를 보인 뒤 발사한다. */
    this.setMode("spiralTele", telegraphMs("spiral"));
    this.setTint(0x9ad0ff);
    this.squash(-0.05, 0.08); // v1.4.9 — 나선 탄막 기모으기
    this.vxWarnRing(this.x, this.y, 0x9ad0ff, 1.3, telegraphMs("spiral") * 0.85);
    this.scene.time.delayedCall(telegraphMs("spiral"), () => this.alive && this.fireSpiral());
  }

  /** 실제 나선 탄막 전개 (P7b — 예고 후 호출) */
  private fireSpiral() {
    this.setMode("volley", 10); // 대기 전용 모드 재사용 (volleyTimer와 무관 — spiralTimer 별도)
    this.spiralAngle = Phaser.Math.FloatBetween(0, Math.PI * 2);
    const arms = this.chaos ? 3 : 2; // 카오스는 3갈래 나선
    const ticks = this.chaos ? 21 : 17;
    let done = 0;
    this.spiralTimer?.remove();
    this.spiralTimer = this.scene.time.addEvent({
      delay: 75,
      repeat: ticks - 1,
      callback: () => {
        if (!this.alive) return;
        this.spiralAngle += 0.52;
        for (let a = 0; a < arms; a++) {
          this.fireOrb(this.spiralAngle + (Math.PI * 2 * a) / arms, 195, Math.round(this.def.atk * 0.5));
        }
        if (done % 4 === 0) this.scene.sfxSwing();
        if (++done >= ticks) {
          this.clearTint();
          this.endAttack(1500);
        }
      },
    });
  }

  /* ---------- 회전 스윕 빔 (nidhog 독 브레스 / surt 화염 / skoll & abudditos) ----------
   * 예고 링 3개 후, 보스에서 뻗어나오는 회전하는 광선(구슬 벽)을 130° 회전 스윕 */
  private startBeam(player: PlayerLike2) {
    this.setMode("beamTele", 780);
    this.setTint(0xffd0a0);
    this.squash(-0.06, 0.1); // v1.4.9 — 브레스 들이마시기
    this.bossFx("hv2_techcircle", this.x, this.y + 8, { tint: 0xffc46a, scale: 0.95, alpha: 0.85, dur: 760 }); // v1.4.11 — 테크 서클 시전 링
    this.beamAngle = Math.atan2(player.y - this.y, player.x - this.x);
    this.beamDir = Math.random() < 0.5 ? 1 : -1;
    // 예고: 시전 방향 직선상 3개 링 (스윕 궤적 암시)
    for (let d = 100; d <= 300; d += 100) {
      const rx = Phaser.Math.Clamp(this.x + Math.cos(this.beamAngle) * d, 40, this.scene.stageW - 40);
      const ry = Phaser.Math.Clamp(this.y + Math.sin(this.beamAngle) * d, 40, this.scene.stageH - 40);
      const ring = this.scene.add
        .image(rx, ry, "ring")
        .setDepth(5)
        .setTint(0xffc46a)
        .setAlpha(0.28)
        .setScale(0.32);
      this.teleRings.push(ring);
      this.scene.tweens.add({ targets: ring, alpha: 0.75, duration: 700 });
      this.scene.time.delayedCall(760, () => {
        if (ring.active) {
          this.scene.tweens.add({ targets: ring, alpha: 0, duration: 140, onComplete: () => ring.destroy() });
          this.teleRings = this.teleRings.filter((r) => r !== ring);
        }
      });
    }
  }

  private doBeam() {
    this.clearTint();
    this.setMode("beaming", 10);
    this.squash(0.05, -0.05); // v1.4.9 — 브레스 분출 반동
    const step = this.chaos ? 0.042 : 0.032; // 카오스는 더 빠른 회전
    const speed = this.chaos ? 250 : 235;
    let done = 0;
    const ticks = 26;
    this.beamTimer?.remove();
    this.beamTimer = this.scene.time.addEvent({
      delay: 60,
      repeat: ticks - 1,
      callback: () => {
        if (!this.alive) return;
        this.beamAngle += this.beamDir * step;
        this.fireOrb(this.beamAngle, speed, Math.round(this.def.atk * 0.55));
        this.fireOrb(this.beamAngle + 0.14, speed, Math.round(this.def.atk * 0.55));
        if (this.chaos) this.fireOrb(this.beamAngle - 0.14, speed, Math.round(this.def.atk * 0.55));
        if (done % 4 === 0) this.scene.sfxSwing();
        if (++done >= ticks) this.endAttack(1600);
      },
    });
  }

  /* ---------- 그림자 급습 (fenrir / skoll / gram / abudditos) ----------
   * 모습을 숨긴 뒤 플레이어 근처로 순간이동 → 짧은 강타 텔레그래프 */
  private startBlink() {
    this.setMode("blinkTele", telegraphMs("blink"));
    this.setAlpha(0.25);
    this.squash(-0.08, 0.1); // v1.4.9 — 그림자로 뭉개지는 수축
    this.scene.spawnBurstAt(this.x, this.y, 14, 0x8040c0);
    this.scene.driveFx?.deathPuff(this.x, this.y - 10, 0x9a7ad8); // v1.4.11 — 소멸 연기
    this.scene.sfxDash();
  }

  private doBlink(player: PlayerLike2) {
    this.setAlpha(1);
    this.squash(0.1, -0.1); // v1.4.9 — 재등장 팝
    const ang = Phaser.Math.FloatBetween(0, Math.PI * 2);
    const d = Phaser.Math.Between(140, 190);
    this.setPosition(
      Phaser.Math.Clamp(player.x + Math.cos(ang) * d, 60, this.scene.stageW - 60),
      Phaser.Math.Clamp(player.y + Math.sin(ang) * d, 60, this.scene.stageH - 60)
    );
    this.scene.spawnBurstAt(this.x, this.y, 14, 0xb06aff);
    this.bossFx("hv2_smoke", this.x, this.y - 8, { tint: 0xb08aff, scale: 0.9, alpha: 0.8, dur: 380, depth: 11 }); // v1.4.11 — 재등장 연기
    // 짧은 강타 — 보라색 링(일반 강타와 구분)
    this.startShadowSlam(player);
  }

  /* ================= vc153 — 스바르트알프헤임 보스 개편 (애니 사양표 상태머신) =================
   *  유저 제공 애니 사양표: ①Idle(Loop) ②Move(Loop) ③GreenSlash(Once) ④Vanish(Once)
   *  ⑤ShieldCast(Once 또는 상태유지) ⑥MagicBurst(Once) ⑦PortalTeleport(Once).
   *  6행 시트(atl_boss3: idle/walk/atk/sp1/sp2/die) 매핑 — atk=GreenSlash · sp1=Vanish · sp2=ShieldCast.
   *  MagicBurst/PortalTeleport는 VX 에셋(vx_expcore/vx_magiccircle)으로 시각 보강. */

  /** ③ GreenSlash(Once) — 근접 녹색 참격 2연 베기 (전방 150px 판정) */
  private startGreenSlash(player: PlayerLike2) {
    /* P7b — 근접 2연 베기의 첫 타를 예고 시간(800ms)에 맞춘다.
     *  종전엔 240ms 뒤 첫 타가 나가 사실상 반응 불가였다. */
    const lead = telegraphMs("greenslash");
    this.setMode("vxCast", lead + 400);
    this.setBossAnim(`${this.def.tex}-atk`); // GreenSlash 행 (Once)
    this.vxWarnRing(player.x, player.y, 0x6aff9a, 1.1, lead * 0.85);
    this.scene.time.delayedCall(telegraphMs("greenslash") + 300, () => this.alive && this.setBossAnim(`${this.def.tex}-idle`));
    const tint = 0x6aff9a; // 녹색 참격
    const strike = (delay: number, mul: number) => {
      this.scene.time.delayedCall(delay, () => {
        if (!this.alive) return;
        const ang = Math.atan2(player.y - this.y, player.x - this.x);
        this.scene.spawnSlash(this.x + Math.cos(ang) * 46, this.y + Math.sin(ang) * 46, new Phaser.Math.Vector2(Math.cos(ang), Math.sin(ang)), true, 2.6, tint);
        this.scene.spawnSlash(this.x + Math.cos(ang) * 78, this.y + Math.sin(ang) * 78, new Phaser.Math.Vector2(Math.cos(ang), Math.sin(ang)), false, 2.2, tint);
        this.scene.spawnBurstAt(this.x + Math.cos(ang) * 52, this.y + Math.sin(ang) * 52, 12, tint);
        this.scene.sfxSwing();
        this.scene.impactFX.shake(90, 0.005);
        if (Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y) < 170) {
          const dir = new Phaser.Math.Vector2(player.x - this.x, player.y - this.y).normalize();
          player.takeDamage(Math.round(this.def.atk * mul), dir, 0.5, this.chaos ? 0.08 : 0);
        }
      });
    };
    strike(lead, 0.85);
    strike(lead + 320, 1.05);
    this.endAttack(1450);
  }

  /** ④ Vanish(Once) → 투명화 — 1.1s 후 재배치 (유저 사양: 소멸 후 재등장)
   *  주의: endAttack을 즉시 호출하면 mode가 idle로 복귀되어 vanished 유지가 깨진다 → doReappear에서 호출 */
  private startVanish() {
    this.setMode("vanished", 1100);
    this.setBossAnim(`${this.def.tex}-sp1`); // Vanish 행 (Once)
    this.scene.time.delayedCall(360, () => {
      if (!this.alive || (this.mode !== "vanished")) return;
      this.setAlpha(0);
      this.scene.spawnBurstAt(this.x, this.y, 16, this.def.orbTint);
      this.scene.driveFx?.deathPuff(this.x, this.y - 10, 0xff8ab0);
      this.scene.sfxDash();
    });
  }

  /** ⑦ 재등장 — Vanish/PortalTeleport 공용: 포탈 링 + 팝 등장 */
  private doReappear(player: PlayerLike2) {
    this.setAlpha(1);
    const ang = Phaser.Math.FloatBetween(0, Math.PI * 2);
    const d = Phaser.Math.Between(150, 210);
    this.setPosition(
      Phaser.Math.Clamp(player.x + Math.cos(ang) * d, 60, this.scene.stageW - 60),
      Phaser.Math.Clamp(player.y + Math.sin(ang) * d, 60, this.scene.stageH - 60)
    );
    /* 포탈 텔레포트 연출 — 룬 링이 열리고 솟아난다 (사양표 ⑦) */
    this.bossFx("hv2_magiccircle2", this.x, this.y + 8, { tint: this.def.orbTint, scale: 1.3, alpha: 0.85, dur: 560, depth: 8 });
    this.scene.spawnBurstAt(this.x, this.y, 16, this.def.orbTint);
    this.scene.vfx3dFx("ring", this.x, this.y, this.def.orbTint, 1.3);
    this.scene.sfxDash();
    this.squash(0.1, -0.1);
    this.setBossAnim(`${this.visualKey || this.def.tex}-idle`);
    /* 재등장 직후 즉보 — 사양표 ③로 연결 */
    this.startGreenSlash(player);
  }

  /** ⑤ ShieldCast(Once→상태유지) — 무적 방어막 3.2s → ⑥ MagicBurst 반격 */
  private startShieldCast() {
    this.setMode("shieldHold", this.chaos ? 2600 : 3200);
    this.setBossAnim(`${this.def.tex}-sp2`); // ShieldCast 행 (Once → 마지막 프레임 상태유지)
    this.shieldInvuln = true;
    /* 방어막 오라 — 청록 결정 링 (상태유지 시각화) */
    this.shieldAura = this.scene.add.image(this.x, this.y - 6, "vx_ring")
      .setDepth(23).setBlendMode(Phaser.BlendModes.ADD).setTint(0x8ad4ff).setScale(1.4).setAlpha(0.8);
    this.scene.tweens.add({ targets: this.shieldAura, scale: 1.8, alpha: 0.45, duration: 700, yoyo: true, repeat: -1 });
    this.setTint(0x9ad8ff);
    /* vc288 — 방어막 남은 시간 게이지.
     *  유저 요구 "보스 방어막 게이지"가 미구현이었다. 종전엔 배너로 "피해 무효"만
     *  알려 주고 **언제 끝나는지**는 알 수 없었다. 그런데 이 방어막은 2.6~3.2초짜리
     *  무적이라, 끝나는 순간을 모르면 헛스윙만 하다가 반격(MagicBurst)을 맞는다.
     *
     *  방어막을 "HP 게이지"로 바꾸지 않는다 — 그건 밸런스 변경이고 지금 계약은
     *  "시간제 무적"이다. 대신 남은 시간을 오라 바깥 링의 각도로 그린다. */
    const shieldMs = this.chaos ? 2600 : 3200;
    this.shieldGauge = this.scene.add.graphics().setDepth(24);
    this.shieldGaugeTimer?.remove();
    this.shieldGaugeTimer = this.scene.time.addEvent({
      delay: 50,
      repeat: Math.ceil(shieldMs / 50) - 1,
      callback: () => {
        const g = this.shieldGauge;
        if (!g) return;
        /* 남은 비율 — modeTimer 가 실제 남은 시간의 단일 출처다(중복 계산 금지). */
        const k = Math.max(0, Math.min(1, this.modeTimer / shieldMs));
        g.clear();
        if (!this.alive || k <= 0) return;
        g.lineStyle(2, 0x8ad4ff, 0.9);
        /* 12시에서 반시계로 줄어드는 호 — 많이 남았을 때가 길다. */
        g.beginPath();
        g.arc(this.x, this.y - 6, 26, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * k, false);
        g.strokePath();
      },
    });
    this.scene.showBanner(`${this.def.name} — 심연의 결정 방어막! (피해 무효)`);
    /* vc273 — "shield" 는 SKILL_SFX_FILES 에 없다. sfx.skill() 이 `if (!file) return;`
     *  로 조용히 무음 처리하므로 이 방어막 전개음은 실제로 나지 않았다.
     *  방어막/보호 계열이므로 guardian·paladin 과 같은 holy 로 맞춘다.
     *  (바로 아래 pxFx.play("shield") 는 픽셀 이펙트 채널이라 별개 — 그대로 둔다.) */
    this.scene.sfxSkill("holy", 0.8);
    /* vc235 — pixelfx "shield" 이벤트 연결 (정의만 되고 호출 0이었다).
     *  보스가 방어막을 두르는 순간이 "지금은 안 통한다"를 알리는 핵심 신호다. */
    try { this.scene.pxFx?.play("shield", this.x, this.y, { scale: 1.1 }); } catch { /* 무시 */ }
  }

  /** 방어막 종료 → ⑥ MagicBurst(Once) 반격 — 추적 기둥 3연 + 종결 대폭발 */
  private doShieldBurst(player: PlayerLike2) {
    this.shieldInvuln = false;
    this.shieldAura?.destroy();
    this.shieldAura = null;
    /* vc288 — 게이지도 같이 정리한다. 안 지우면 방어막이 끝난 뒤에도
     *  파란 호가 허공에 남는다. */
    this.shieldGaugeTimer?.remove();
    this.shieldGaugeTimer = null;
    this.shieldGauge?.destroy();
    this.shieldGauge = null;
    /* vc288 — 방어막이 터지는 순간 **스킬을 봉인**한다.
     *  종전엔 이 반격이 그냥 큰 피해였고, 플레이어는 계속 스킬을 쓸 수 있었다.
     *  이제 "방어막 뒤에 뭔가 온다"는 것을 배우게 된다 — 방어막을 보면 거리를 벌리고
     *  평타로 버티는 선택을 하게 된다. 이것이 침묵 상태이상의 첫 실사용처다.
     *  지속 2.5초: 반격(MagicBurst 2.1초)과 겹치는 구간에만 걸려 "대응 불가"가 되지 않는다. */
    player.applySilence?.(2500);
    this.clearTint();
    this.setMode("vxCast", 2100);
    this.setBossAnim(`${this.def.tex}-atk`);
    this.scene.time.delayedCall(900, () => this.alive && this.setBossAnim(`${this.def.tex}-idle`));
    this.scene.showBanner(`${this.def.name} — 방어막이 폭발한다!`);
    const atk = this.def.atk;
    const tint = this.def.orbTint;
    let n = 0;
    const strike = () => {
      if (!this.alive || n >= 3) {
        /* 종결 대폭발 — MagicBurst 클라이맥스 */
        this.scene.time.delayedCall(160, () => {
          if (!this.alive) return;
          const g = this.scene.add.image(this.x, this.y, "vx_ring").setDepth(23).setBlendMode(Phaser.BlendModes.ADD).setTint(tint).setScale(0.5).setAlpha(0.95);
          this.scene.tweens.add({ targets: g, scale: 6.0, alpha: 0, duration: 460, ease: "Quad.out", onComplete: () => g.destroy() });
          this.vxAnimAt(this.x, this.y, "vx-expcore", "vx_expcore", 0xffffff, 1.9);
          this.scene.vfx3dFx("boom", this.x, this.y, tint, 2.0);
          this.scene.impactFX.shake(240, 0.011);
          if (Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y) < 250) {
            const dir = new Phaser.Math.Vector2(player.x - this.x, player.y - this.y).normalize();
            player.takeDamage(Math.round(atk * 1.3), dir, 0.5, this.chaos ? 0.12 : 0);
          }
          this.endAttack(1200);
        });
        return;
      }
      n++;
      const tx = player.x, ty = player.y;
      this.vxWarnRing(tx, ty, 0x8ad4ff, 0.9, 400);
      this.scene.time.delayedCall(400, () => {
        if (!this.alive) return;
        this.vxAnimAt(tx, ty, "vx-expcore", "vx_expcore", tint, 1.4);
        this.scene.spawnSlamBurst(tx, ty);
        this.scene.impactFX.shake(70, 0.004);
        if (Phaser.Math.Distance.Between(tx, ty, player.x, player.y) < 92) {
          const dir = new Phaser.Math.Vector2(player.x - tx, player.y - ty).normalize();
          player.takeDamage(Math.round(atk * 1.0), dir, 0.5, this.chaos ? 0.09 : 0);
        }
        strike();
      });
    };
    strike();
  }

  /** 방어막/투명화 잔존 정리 — 사망·페이즈 전환 시 호출 보장 */
  private cleanupSvartStates() {
    this.shieldInvuln = false;
    if (this.shieldAura) { this.shieldAura.destroy(); this.shieldAura = null; }
    this.setAlpha(1);
  }

  /** blink 직속 강타 — 일반 강타보다 텔레그래프가 짧고(500ms) 보라색 */
  private startShadowSlam(player: PlayerLike2) {
    this.setMode("slamTele", this.chaos ? 380 : 500);
    const ring = this.scene.add
      .image(player.x, player.y, "ring")
      .setDepth(5)
      .setTint(0xb06aff)
      .setAlpha(0.4)
      .setScale(0.2);
    this.teleRings.push(ring);
    this.teleRing = ring;
    this.scene.tweens.add({ targets: ring, scale: 1, alpha: 0.9, duration: (this.chaos ? 380 : 500) - 30 });
    this.setTint(0xb06aff);
    this.scene.time.delayedCall(this.chaos ? 380 : 500, () => this.alive && this.clearTint());
  }

  /* ---------- 연속 낙뢰 (guardian 심연 지진 / surt 용암 분출 / behemoth 눈보라 폭풍) ----------
   * 플레이어를 쫓는 연속 낙뢰 장판 — 6~8회 연속으로 이동기 강제 */
  private startQuake() {
    /* P7b — 종전 80ms 는 "한 번 맞고 시작"에 가까웠다. 첫 낙뢰 전에 예고를 세운다.
     *  quake 는 340ms 간격 연사이므로 첫 타만 예고하면 이후는 리듬으로 읽힌다. */
    this.setMode("quakeCast", telegraphMs("quake"));
    this.setTint(0xffb05a);
    this.vxWarnRing(this.x, this.y, 0xffa040, 1.6, telegraphMs("quake") * 0.85);
    const shots = this.chaos ? 8 : 6;
    this.quakeTimer?.remove();
    let done = 0;
    this.quakeTimer = this.scene.time.addEvent({
      delay: 340,
      repeat: shots - 1,
      callback: () => {
        if (!this.alive) return;
        const p0 = this.scene.playerRef;
        if (!p0) return;
        // 70% 확률 플레이어 현재 위치, 30%는 예측 차단용 근처 무작위
        const tx =
          Math.random() < 0.7
            ? p0.x
            : Phaser.Math.Clamp(p0.x + Phaser.Math.Between(-240, 240), 60, this.scene.stageW - 60);
        const ty =
          Math.random() < 0.7
            ? p0.y
            : Phaser.Math.Clamp(p0.y + Phaser.Math.Between(-200, 200), 60, this.scene.stageH - 60);
        const ring = this.scene.add
          .image(tx, ty, "ring")
          .setDepth(5)
          .setTint(0xffa040)
          .setAlpha(0.35)
          .setScale(0.18);
        this.zoneRings.push(ring);
        this.scene.tweens.add({ targets: ring, scale: 0.8, alpha: 0.9, duration: 580 });
        this.scene.time.delayedCall(600, () => {
          if (!ring.active) return;
          this.scene.spawnSlamBurst(ring.x, ring.y);
          /* v1.4.11 — 낙뢰 섬광 (hv2_electro — 지진 임팩트)
           * vc142 (#7) — hv2_crater 데칼 제거 (검은 네모 이질 연출 — 유저 지시) */
          this.bossFx("hv2_electro", ring.x, ring.y, { tint: 0xffd28a, scale: 1.25, alpha: 0.95, dur: 200, depth: 27 });
          this.scene.driveFx?.shockHeavy(ring.x, ring.y, 0xffc890, 0.95);
          this.scene.impactFX.shake(80, 0.004);
          const p = this.scene.playerRef;
          if (p && Phaser.Math.Distance.Between(ring.x, ring.y, p.x, p.y) < 88) {
            const dir = new Phaser.Math.Vector2(p.x - ring.x, p.y - ring.y).normalize();
            p.takeDamage(Math.round(this.def.atk * 0.8), dir);
          }
          this.scene.tweens.add({ targets: ring, alpha: 0, duration: 140, onComplete: () => ring.destroy() });
          this.zoneRings = this.zoneRings.filter((r) => r !== ring);
        });
        if (done % 2 === 0) this.scene.sfxSwing();
        if (++done >= shots) {
          this.clearTint();
          this.endAttack(shots * 340 + 260);
        }
      },
    });
  }

  /* ---------- 반격 카운터 (abysslord / gram / abudditos — 로스트아크식) ----------
   * 노란 링 = 반격의 창. 창 안에 1회라도 맞추면 보스가 기절+취약(받는 피해 ×1.6),
   * 방관하면 즉시 대폭발(링 2파동 + 장판)으로 응수 */
  private startCounter() {
    this.setMode("counterTele", counterWindowMs(this.chaos));
    this.setTint(0xffe95a);
    this.squash(-0.06, 0.06); // v1.4.9 — 반격 자세
    this.counterRing = this.scene.add
      .image(this.x, this.y, "ring")
      .setDepth(5)
      .setTint(0xffe95a)
      .setAlpha(0.5)
      .setScale(1.15);
    this.teleRings.push(this.counterRing);
    this.scene.tweens.add({ targets: this.counterRing, scale: 0.9, alpha: 0.95, duration: 300, yoyo: true, repeat: -1 });
    /* v1.4.30 (#15 반격 UX) — 링 위에 "반격! 공격" 라벨을 상시 띄운다.
     *  기존엔 첫 2회 배너 힌트뿐이라 창이 왔는지 인지 못해 방관→응징 폭발을 당했다.
     *  이제 라벨이 창이 열릴 때마다 보스 머리 위에 떠서 "지금 때려야 한다"가 즉시 보인다. */
    const lbl = this.scene.add
      .text(this.x, this.y - 66, "반격! 공격 ➤", {
        fontFamily: "Galmuri11, sans-serif", fontSize: "14px", color: "#ffe95a",
        stroke: "#1a1020", strokeThickness: 5, fontStyle: "bold",
      })
      .setOrigin(0.5)
      .setDepth(26);
    this.scene.tweens.add({ targets: lbl, y: this.y - 74, alpha: { from: 1, to: 0.72 }, duration: 260, yoyo: true, repeat: -1 });
    this.counterLabel = lbl;
    if (this.counterHintShown < 2) {
      this.counterHintShown++;
      this.scene.showBanner("노란 원이 보이면 — 창이 닫히기 전에 보스를 1번 때려라! (성공 시 기절+피해 ×1.6)");
    }
    this.scene.sfxRoar();
  }

  /** 카운터 창 방관 — 응징 폭발 */
  private doCounterPunish(player: PlayerLike2) {
    this.clearTint();
    this.destroyCounterRing();
    this.scene.impactFX.shake(200, 0.009);
    this.scene.showBanner("반격 실패!");
    this.setTint(0xff7a5a);
    // 즉시 링 2파동 (틀어진 각도)
    for (let w = 0; w < 2; w++) {
      this.scene.time.delayedCall(w * 320, () => {
        if (!this.alive) return;
        const count = 20;
        for (let i = 0; i < count; i++) {
          this.fireOrb(w * 0.19 + (Math.PI * 2 * i) / count, 175 + w * 25, Math.round(this.def.atk * 0.55));
        }
      });
    }
    // 근거리 장판 2개
    const spots: [number, number][] = [
      [player.x, player.y],
      [this.x, this.y],
    ];
    for (const [zx, zy] of spots) {
      const ring = this.scene.add.image(zx, zy, "ring").setDepth(5).setTint(0xff8848).setAlpha(0.35).setScale(0.2);
      this.zoneRings.push(ring);
      this.scene.tweens.add({ targets: ring, scale: 0.82, alpha: 0.9, duration: 800 });
      this.scene.time.delayedCall(830, () => {
        if (!ring.active) return;
        this.scene.spawnSlamBurst(ring.x, ring.y);
        if (Phaser.Math.Distance.Between(ring.x, ring.y, player.x, player.y) < 95) {
          const dir = new Phaser.Math.Vector2(player.x - ring.x, player.y - ring.y).normalize();
          player.takeDamage(Math.round(this.def.atk * 0.9), dir);
        }
        this.scene.tweens.add({ targets: ring, alpha: 0, duration: 150, onComplete: () => ring.destroy() });
        this.zoneRings = this.zoneRings.filter((r) => r !== ring);
      });
    }
    this.scene.time.delayedCall(900, () => this.alive && this.clearTint());
    this.endAttack(1900);
  }

  private destroyCounterRing() {
    if (this.counterRing && this.counterRing.active) {
      this.scene.tweens.killTweensOf(this.counterRing);
      this.counterRing.destroy();
    }
    this.teleRings = this.teleRings.filter((r) => r !== this.counterRing);
    this.counterRing = null;
    /* v1.4.30 (#15) — 라벨도 같이 정리 */
    if (this.counterLabel && this.counterLabel.active) {
      this.scene.tweens.killTweensOf(this.counterLabel);
      this.counterLabel.destroy();
    }
    this.counterLabel = null;
  }

  private fireOrb(angle: number, speed: number, dmgOverride?: number) {
    const orb = this.orbPool[this.orbIdx];
    this.orbIdx = (this.orbIdx + 1) % this.orbPool.length;
    orb.enableBody(true, this.x, this.y - 20, true, true);
    // v4.1.4 — 카오스는 탄속 +22% (회피 난이도 상향)
    this.scene.physics.velocityFromRotation(angle, this.chaos ? speed * 1.22 : speed, orb.body!.velocity);
    orb.setScale(this.enraged ? 1.2 : 1);
    orb.setData(
      "dmg",
      dmgOverride ?? (this.enraged ? Math.round(this.def.atk * 0.75) : Math.round(this.def.atk * 0.6))
    );
    // 수명 후 자동 회수
    this.scene.time.delayedCall(3200, () => this.killOrb(orb));
  }

  private killOrb(orb: Phaser.Physics.Arcade.Image) {
    if (!orb.active) return;
    orb.disableBody(true, true);
  }

  /** 공격 종료 — 다음 공격까지 대기. v3.0.6: 페이즈별 태진 단축 (p1 0.85 / p2 0.7 / 격노 0.5)
   *  v4.1.4 — 카오스는 쿨타임 25% 추가 단축 (패턴 밀도 대폭 상향)
   *  P7b — 직전 패턴에 맞는 **반격 창(recover)** 을 먼저 열고 나서 쿨다운을 센다.
   *   유저 요구 "패턴 사이의 반격 기회" — 종전엔 곧바로 idle 로 돌아가 다음 패턴을
   *   준비했으므로, 보스가 계속 공격만 하는 것처럼 보였다. */
  private endAttack(cd: number) {
    /* 반격 창: 패턴별 1~2초(bossPhases.RECOVERY_MS). 창이 열린 동안 피해 ×1.15. */
    const win = this.lastAttack ? recoveryMs(this.lastAttack) : 0;
    if (win > 0 && this.alive) {
      this.mode = "recover";
      this.modeTimer = win;
      this.setTint(0xc8b0ff); // 무방비 표시 — 카운터(노랑)와 구분되는 보라
      /* 창 진입을 알리는 짧은 링 1개. 매 프레임 생성이 아니라 패턴 종료 1회만. */
      this.vxWarnRing(this.x, this.y, 0xc8b0ff, 1.15, win * 0.8);
    } else {
      this.mode = "idle";
    }
    let m = attacksAfter(this.phase) / 1000; // P7b — 페이즈별 쿨타임 단일 출처
    if (this.chaos) m *= 0.75;
    /* v1.4.12 (#20) — 보스별 공격 성향 (aggr: 1보다 작으면 더 빠르게 다시 공격) */
    if (this.def.aggr) m *= this.def.aggr;
    this.nextAttackCd = cd * m;
  }

  /* ---------- 피격/사망 ---------- */

  /* v1.4.16 — 원소 반응 쿨다운 (보스도 같은 규칙 적용 — CC는 면역) */
  private lastReactAt = 0;

  /* ============ vc143 (#4 공유 보스 체력) ============
   *  공동 토벌전·파티 보스전에서 파티원이 같은 보스 HP를 공유한다.
   *  · 호스트: 로컬 딜 + 원격 bdmg 합산 → 250ms bhp 브로드캐스트 (사망 권한)
   *  · 비호스트: 딜 연출만, HP는 호스트 bhp로 스냅 — 사망은 호스트 dead 통지로만
   *  WorldScene.setupBossShare()이 스폰 직후 세팅한다 */
  sharedMode = false;
  sharedIsHost = false;
  sharedHp = 0;
  /** 피격 확정분 통보 훅 — 호스트는 합산, 비호스트는 릴레이 (WorldScene 주입) */
  onSharedDamage?: (dealt: number) => boolean | void;
  absorbMechanicDamage(dealt: number): boolean { return dealt > 0 && (this.story?.interceptDamage(dealt) ?? false); }
  healFromBlood(): void {
    if (this.sharedMode && !this.sharedIsHost) return;
    const amount = Math.min(this.maxHp - this.hp, this.maxHp * .015);
    this.hp += amount;
    if (this.sharedMode && amount > 0) this.onSharedDamage?.(-amount);
    EventBus.emit("boss:update", { hp: this.hp, maxHp: this.maxHp });
  }

  /* v1.4.30 (#7 이터널 실성능) — "시간의 잠금": 보스가 받는 유일한 CC.
   *  일반 몹의 applyStun과 달리 보스는 최대 1.4초의 경직(staggered, 피해 ×1.6)으로
   *  완화되어 들어간다 — 이터널 영원의 고리·영겁극의 시간 정지가 보스전에서도 의미를 갖는다.
   *  반격 카운터 대기 중에는 카운터 창을 지키기 위해 무시한다. */
  /* vc183 (극딜 문서) — 보스 지속 피해(출혈/중독). 종전엔 보스에 도트를 거는 수단이 없어
   *  4차 궁극기의 "출혈 중첩"이 보스전에서 아무 효과도 없었다.
   *  보스는 도트 저항을 40% 갖는다(일반 몹 대비) — 즉사급 누적을 막으면서 의미는 유지. */
  private dotUntil = 0;
  private dotDps = 0;
  private dotNext = 0;
  applyDot(dps: number, durMs: number) {
    if (!this.alive) return;
    this.dotDps = Math.max(this.dotDps, dps * 0.6);
    this.dotUntil = Math.max(this.dotUntil, this.scene.time.now + durMs);
  }
  private tickDot(now: number) {
    if (this.dotDps <= 0 || now > this.dotUntil) { this.dotDps = 0; return; }
    if (now < this.dotNext) return;
    this.dotNext = now + 500;
    try {
      this.takeDamage(Math.max(1, Math.round(this.dotDps * 0.5)), new Phaser.Math.Vector2(0, 0), 0, false);
    } catch { this.dotDps = 0; }
  }

  applyStun(ms: number) {
    if (!this.alive) return;
    if (this.mode === "counterTele") return;
    const clamp = Math.min(1400, Math.max(600, ms));
    this.mode = "staggered";
    this.modeTimer = clamp;
    this.setTint(0x8a7aff);
    this.setVelocity(0, 0);
    this.scene.spawnPickupText?.(this.x, this.y - 56, "시간의 잠금!", "#d8ccff");
    this.scene.spawnBurstAt(this.x, this.y, 12, 0xb0a0ff);
    EventBus.emit("boss:update", { hp: Math.max(0, this.hp), maxHp: this.maxHp });
  }

  takeDamage(dmg: number, dir: Phaser.Math.Vector2, knock: number, crit = false) {
    if (!this.alive) return;
    this.scene.notePlayerHit?.(dmg); // v1.1.5 (#개편 통계) — 최고 타격 기록
    /* vc153 — 스바르트알프헤임 방어막: ShieldCast 상태유지 중 피해 무효 (사양표 ⑤) */
    if (this.shieldInvuln) {
      this.scene.spawnPickupText?.(this.x, this.y - 60, "무효", "#8ad4ff");
      return;
    }
    /* v1.4.30 (#2 사냥/보스 밸런스) — 보스 특화 직업(전사·데드아이·아크로드·섀도우로드 등)
     *  체인 합산 bossDmgPct만큼 보스에게 주는 피해 증가 */
    const spec = this.scene.playerRef ? (this.scene.playerRef as unknown as { bossDmgBonus?: number }).bossDmgBonus ?? 0 : 0;
    dmg = Math.max(1, Math.round(dmg * (1 + spec / 100)));
    /* v3.0.15 (#16) — 보스도 챕터 테마 원소를 가진다 (상성 배율 적용) */
    const atkElem = this.scene.playerRef?.attackElem ?? "none";
    const adv = elemAdvantage(atkElem, this.elem);
    const weak = adv > 1;
    /* v1.4.16 — 보스 원소 반응: 연출+데미지 보너스만 (스플래시/기절/슬로우 면역 — 보스전 밸런스) */
    const now = this.scene.time.now;
    const reactKey = elementReaction(atkElem, this.elem);
    const reacted = !!reactKey && now - this.lastReactAt > 1600;
    if (reacted && reactKey) {
      this.lastReactAt = now;
      this.scene.spawnElementReaction(this.x, this.y - 20, reactKey);
    }
    const R = reacted && reactKey ? ELEM_REACTION_META[reactKey] : null;
    /* vc183 (지시 — 적에게도 방어력) — 보스도 정액+비율 방어력을 갖는다.
     *  보스는 기본 비율 방어 8%를 적용해 "스킬이 그대로 꽂히는" 후반 인플레를 완화한다.
     *  def/defPct 를 정의에서 지정하면 그 값이 우선한다(spawnBoss에서 기본값 주입). */
    const raw = R ? Math.max(1, Math.round(dmg * adv * R.dmgMul))
      : adv === 1 ? dmg : Math.max(1, Math.round(dmg * adv));
    let dealt = mitigateEnemyDamage(raw, { def: this.def.def ?? 0, defPct: this.def.defPct ?? 0 });
    /* v1.4.31 — 교실 모드 공유 보스 레이드: 보스에 넣은 피해도 합산 (기존은 일반 몬스터만 카운트되는
     *  블라인드스팟 — Enemy.takeDamage의 trackDamage와 짝을 이룬다. 교실 밖 no-op) */
    trackDamage(dealt);

    // v4.1.4 — 반격 카운터: 창(노란 링) 안에 한 대라도 맞추면 카운터 성공 → 기절 + 취약
    if (this.mode === "counterTele") {
      this.clearTint();
      this.destroyCounterRing();
      this.mode = "staggered";
      this.modeTimer = 2800;
      this.setTint(0x8a7aff);
      this.scene.showBanner("반격 성공 — " + this.def.name + " 대굴! (피해 ×1.6)");
      this.scene.impactFX.shake(160, 0.008);
      this.scene.spawnBurstAt(this.x, this.y, 22, 0xffe95a);
      EventBus.emit("boss:update", { hp: Math.max(0, this.hp), maxHp: this.maxHp });
      return; // 이 한 대는 그대로 반영 — 이후 타격부터 ×1.6
    }
    if (this.mode === "staggered") dealt = Math.max(1, Math.round(dealt * 1.6)); // 취약 상태
    /* P7b — 반격 창(recover) 보너스. 기절(×1.6)보다 약하게, 평시(×1)보다 세게.
     *  "패턴 사이에 때리면 확실히 이득"이 되어야 플레이어가 그 리듬을 학습한다. */
    else if (this.mode === "recover") dealt = Math.max(1, Math.round(dealt * RECOVER_DMG_MULT));

    /* vc143 (#4 공유 체력) — 비호스트는 HP 권한이 없다: 연출만 수행하고 HP 감소·사망 판정은
     *  생략한다. 권위 HP는 호스트의 bhp 브로드캐스트로 동기된다 */
    const hpAuthority = !(this.sharedMode && !this.sharedIsHost);
    if (this.sharedMode) { if (this.onSharedDamage?.(dealt)) return; }
    else if (this.absorbMechanicDamage(dealt)) return;
    if (hpAuthority) this.hp -= dealt;
    this.knockVec.set(dir.x * knock * (canonBossOf(this.def.key)?.finish === "ringout" ? 3.5 : .12), dir.y * knock * (canonBossOf(this.def.key)?.finish === "ringout" ? 3.5 : .12)); // 보스는 넉백 거의 안 됨
    this.squash(0.035, -0.035); // v1.4.9 — 피격 미세 진동
    // 타격감: 화이트 플래시 — 카운터/기절 상태의 틴트는 유지
    this.setTint(0xffffff).setTintMode(Phaser.TintModes.FILL);
    this.scene.time.delayedCall(60, () => {
      if (!this.alive || !this.active) return;
      if (this.mode === "staggered") this.setTint(0x8a7aff);
      /* P7b — 반격 창(recover) 틴트도 유지한다. 안 그러면 한 대 맞자마자
       *  무방비 표시가 사라져 "지금 때려도 되는가"를 알 수 없다. */
      else if (this.mode === "recover") this.setTint(0xc8b0ff);
      else if (this.mode !== "counterTele") this.clearTint();
    });
    this.scene.spawnDamageText(
      this.x + Phaser.Math.Between(-14, 14), this.y - 44, dealt, crit || weak,
      weak ? ELEMENT_META[this.elem].color : undefined, weak ? "약점" : undefined
    );
    this.scene.spawnHitSpark(this.x, this.y - 30);
    /* v4.8.0 — 보스에게 먹힌 크리티컬은 더 큰 충격파로 (격판 강조, WebGL 전용) */
    if (crit) { this.scene.spawnShockwave(this.x, this.y - 24, 0xffd76a, 1.3, 400); this.scene.spawnCritSplat(this.x, this.y - 20, 0xffd76a); }
    EventBus.emit("boss:update", { hp: Math.max(0, this.sharedMode && !this.sharedIsHost ? Math.round(this.sharedHp) : this.hp), maxHp: this.maxHp });

    if (hpAuthority && this.hp <= 0) {
      this.hp = 0;
      this.alive = false;
      this.mode = "dead";
      this.story?.destroy();
      if (canonBossOf(this.def.key)?.finish === "repel") this.scene.showBanner(`${this.def.name} — 국면 돌파`);
      this.setBossAnim(`${this.visualKey || this.def.tex}-die`); // v5.0 — 사망 애니 (미보유 시 idle 폴백)
      this.volleyTimer?.remove();
      this.spiralTimer?.remove();
      this.beamTimer?.remove();
      this.quakeTimer?.remove();
      this.supportTimer?.remove();
      this.scene.tweens.killTweensOf(this); // v4.1.4 — 카오스 오라 펄스 정지
      this.setAlpha(1);
      this.cleanupSvartStates(); // vc153 — 방어막 오라/무적 잔존 정리 (사망 시에도)
      /* v4.9.3 — pixelfx 보스 사망 연출 (대형 폭발 + 영혼 상승) */
      try {
        this.scene.pxFx?.boss("boss.death", this.x, this.y, { scale: 1.8 });
        /* vc235 — death.boss 이벤트도 함께 (정의만 되고 호출 0이었다).
         *  보스 격파는 게임에서 가장 큰 순간이라 대형 폭발·영혼 상승을 겹친다. */
        this.scene.pxFx?.play("death.boss", this.x, this.y, { scale: 1.6, depth: 26 });
      } catch { /* 무시 */ }
      /* v1.4.9 — 사망 연출 강화: 오라색 잔상 3겹 확산 + 본체 소멸 트윈 + 2중 충격파 */
      {
        const gx = this.x, gy = this.y;
        const gtex = this.texture.key;
        const gframe = this.frame.name; // v1.4.31 — 아틀라스 보스 잔상은 현재 프레임 유지 (__BASE는 구형)
        const gfl = this.flipX;
        const gsx = this.scaleX, gsy = this.scaleY;
        for (let i = 0; i < 3; i++) {
          const ghost = this.scene.add.image(gx, gy, gtex, gframe)
            .setDepth(10)
            .setTint(this.def.orbTint)
            .setBlendMode(Phaser.BlendModes.ADD)
            .setAlpha(0.5)
            .setScale(gsx, gsy)
            .setFlipX(gfl);
          this.scene.tweens.add({
            targets: ghost,
            alpha: 0,
            scaleX: gsx * (1.3 + i * 0.22),
            scaleY: gsy * (1.3 + i * 0.22),
            duration: 620 + i * 150,
            ease: "Cubic.easeOut",
            onComplete: () => ghost.destroy(),
          });
        }
        this.scene.tweens.add({
          targets: this,
          alpha: 0,
          scaleX: gsx * 1.1,
          scaleY: gsy * 0.88,
          duration: 850,
          ease: "Cubic.easeIn",
        });
        this.scene.time.delayedCall(160, () => this.scene.spawnShockwave(gx, gy, this.def.orbTint, 1.1, 420));
        this.scene.time.delayedCall(340, () => this.scene.spawnShockwave(gx, gy, 0xffffff, 0.85, 340));
        /* v1.4.11 — 최후 폭발 + 상승 연기 (mg_explode·mg_smoke — Drive 팩 종결 연출) */
        this.bossFx("mg_explode", gx, gy - 10, { tint: this.def.orbTint, scale: 1.7, alpha: 0.95, dur: 420, depth: 26 });
        this.bossFx("mg_smoke", gx, gy - 22, { tint: 0xcfc6de, scale: 1.3, alpha: 0.7, dur: 800, depth: 12 });
      }
      for (const orb of this.orbPool) this.killOrb(orb);
      for (const r of this.teleRings) r.destroy();
      this.teleRings = [];
      for (const r of this.zoneRings) r.destroy();
      this.zoneRings = [];
      this.twin?.destroy(); this.twin = null; // v1.0.12 — 하티 동반 소멸
      this.setVelocity(0, 0);
      // 보스 격파 보상 — 대량 골드 + HP 물약 2개 (2D MMORPG 기본 요소)
      this.scene.dropLootGold(this.x, this.y, this.def.gold);
      this.scene.dropLootItem(this.x + 26, this.y, "potion_hp");
      this.scene.dropLootItem(this.x - 26, this.y, "potion_hp");
      EventBus.emit("boss:hide");
      this.scene.onBossDead();
      this.scene.time.delayedCall(900, () => this.destroy());
    }
  }

  /** vc143 (#4 공유 체력) — 공유 HP 기준 사망 강제.
   *  호스트: 합산 HP 0 도달 시 / 비호스트: 호스트 dead 통지 수신 시 호출.
   *  남은 HP 전량을 takeDamage로 통과시켜 기존 사망 연출·보상 경로(onBossDead)를 그대로 재사용 */
  forceSharedDeath() {
    if (!this.alive) return;
    this.story?.destroy(); this.story = null;
    this.sharedMode = false; this.shieldInvuln = false;
    this.hp = 1; this.mode = "idle";
    this.takeDamage(this.maxHp * 100, new Phaser.Math.Vector2(0, 1), 0, false);
  }

  destroyPool() {
    this.recoveryLabel?.destroy(); this.recoveryLabel = null;
    this.story?.destroy(); this.story = null;
    this.volleyTimer?.remove();
    this.spiralTimer?.remove();
    this.beamTimer?.remove();
    this.quakeTimer?.remove();
    this.supportTimer?.remove();
    /* vc288 — 카운트다운 타이머도 정리한다. 남겨 두면 보스가 죽은 뒤에도
     *  "2 / 1 / 시작!" 배너가 계속 뜬다. */
    this.countdownTimer?.remove();
    this.countdownTimer = null;
    this.countdown = 0;
    /* vc288 — 방어막 게이지 정리 (씬 전환/사망 시 허공에 남지 않도록) */
    this.shieldGaugeTimer?.remove();
    this.shieldGaugeTimer = null;
    this.shieldGauge?.destroy();
    this.shieldGauge = null;
    /* vc288 (B39) — 격노 오라 정리. 사망 후에도 붉은 고리가 남으면 시체가 맥동한다. */
    this.enrageAuraTimer?.remove();
    this.enrageAuraTimer = null;
    this.enrageAura?.destroy();
    this.enrageAura = null;
    this.twin?.destroy(); this.twin = null; // v1.0.12 — 씬 정리 시 하티 제거
    for (const orb of this.orbPool) orb.destroy();
    for (const r of this.teleRings) r.destroy();
    for (const r of this.zoneRings) r.destroy();
    this.orbPool = [];
    this.teleRings = [];
    this.zoneRings = [];
    this.counterRing = null;
    /* v1.4.30 (#15) — 반격 라벨도 정리 */
    if (this.counterLabel && this.counterLabel.active) this.counterLabel.destroy();
    this.counterLabel = null;
  }
}

export interface PlayerLike2 {
  x: number;
  y: number;
  hp: number;
  /** v3.0.6 — pierce(0~1): 방어력 관통, hpPct(0~1): maxHP % 고정 피해 하한 (보스 공격 전용) */
  takeDamage(dmg: number, fromDir: Phaser.Math.Vector2, pierce?: number, hpPct?: number): void;
  /** vc288 — 침묵 부여(스킬 봉인). 보스가 "스킬을 봉인한다" 패턴을 쓸 때 호출한다.
   *  optional 로 둔 이유: 테스트 더미/옛 호출부가 이 메서드 없이도 동작해야 한다. */
  applySilence?(ms: number): void;
}
