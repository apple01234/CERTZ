import type Phaser from "phaser";
import manifest from "../../../public/assets/story-bosses/manifest.json" with { type: "json" };

export function preloadStoryBosses(scene: Phaser.Scene): void {
  for (const b of manifest.bosses) scene.load.atlas(b.texture, `story-bosses/${b.id}.png`, `story-bosses/${b.id}.json`);
}
export function registerStoryBosses(scene: Phaser.Scene): void {
  for (const b of manifest.bosses) {
    if (!scene.textures.exists(b.texture)) continue;
    const atlas = scene.textures.get(b.texture);
    const framesFor = (row: string) => atlas.getFrameNames().filter(n => n.startsWith(`${row}-`))
      .sort((a, b) => Number(a.split("-").at(-1)) - Number(b.split("-").at(-1)));
    for (const [name, row, rate] of [["idle", "idle", 4], ["walk", "walk", 8], ["atk", "attack", 9], ["sp1", "cast", 7], ["sp2", "cast", 7], ["sp3", "cast", 7], ["die", "idle", 3]] as const) {
      const key = `${b.texture}-${name}`;
      if (!scene.anims.exists(key)) scene.anims.create({ key, frames: framesFor(row).map(frame => ({ key: b.texture, frame })), frameRate: rate, repeat: name === "idle" || name === "walk" ? -1 : 0 });
    }
    const attack = framesFor("attack");
    const impact = Math.max(1, Math.floor(attack.length / 2));
    for (const [name, frames] of [["windup", attack.slice(0, impact)], ["release", attack.slice(impact)]] as const) {
      const key = `${b.texture}-${name}`;
      if (!scene.anims.exists(key)) scene.anims.create({ key, frames: frames.map(frame => ({ key: b.texture, frame })), frameRate: name === "release" ? 16 : 8, repeat: 0 });
    }
  }
}
